import React from 'react';
import { 
  LayoutDashboard, 
  AlertTriangle, 
  PlusCircle, 
  Sparkles, 
  Database, 
  Settings, 
  BrainCircuit, 
  CheckCircle2, 
  ShieldCheck,
  X
} from 'lucide-react';
import { HindsightStatus } from '../types';

export type PageId = 'dashboard' | 'incidents' | 'new-incident' | 'ai-analysis' | 'memory-explorer' | 'incident-detail' | 'settings';

interface SidebarProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
  pendingAnalysisCount?: number;
  hindsightStatus?: HindsightStatus;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onNavigate,
  isOpenMobile,
  onCloseMobile,
  hindsightStatus,
}) => {
  const navItems = [
    { id: 'dashboard' as PageId, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'incidents' as PageId, label: 'Incidents', icon: AlertTriangle },
    { id: 'new-incident' as PageId, label: 'New Incident', icon: PlusCircle },
    { id: 'ai-analysis' as PageId, label: 'AI Analysis', icon: Sparkles },
    { id: 'memory-explorer' as PageId, label: 'Memory Explorer', icon: Database },
    { id: 'settings' as PageId, label: 'Settings', icon: Settings },
  ];

  const handleNavClick = (id: PageId) => {
    onNavigate(id);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpenMobile && (
        <div 
          onClick={onCloseMobile}
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-40 lg:hidden"
          aria-hidden="true"
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 bg-[#0F172A] border-r border-slate-800/80 flex flex-col justify-between transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Top: Logo & Title */}
        <div>
          <div className="h-16 px-6 border-b border-slate-800/80 flex items-center justify-between">
            <button
              onClick={() => handleNavClick('dashboard')}
              className="flex items-center gap-2.5 text-left group focus:outline-hidden"
            >
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center shadow-md shadow-purple-900/30 text-white group-hover:scale-105 transition-transform">
                <BrainCircuit className="w-5 h-5 text-purple-100" />
              </div>
              <div>
                <div className="font-semibold text-base tracking-tight text-white flex items-center gap-1.5">
                  MemoryOps
                </div>
                <div className="text-[11px] font-medium text-slate-400">
                  AI Incident Response
                </div>
              </div>
            </button>

            <button
              onClick={onCloseMobile}
              className="p-1.5 text-slate-400 hover:text-white rounded-md lg:hidden"
              aria-label="Close menu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="p-3 space-y-1" aria-label="Main Navigation">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-purple-600/15 text-purple-300 border border-purple-500/30 shadow-xs'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive ? 'text-purple-400' : 'text-slate-400 group-hover:text-slate-200'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                  {item.id === 'ai-analysis' && (
                    <span className="ml-auto text-[10px] px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono">
                      Hindsight
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom: System Status & Version */}
        <div className="p-4 border-t border-slate-800/80 bg-slate-900/40">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-2.5">
            System Status
          </div>
          <div className="space-y-1.5 text-xs text-slate-300">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>AI Engine Online</span>
            </div>
            <div className="flex items-center gap-2">
              {hindsightStatus?.connected ? (
                <>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Hindsight Cloud Active</span>
                </>
              ) : (
                <>
                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                  <span className="text-amber-300">Hindsight Cloud Offline</span>
                </>
              )}
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span className="text-slate-400">All Systems Operational</span>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
              <span>v1.0 Demo</span>
            </span>
            <span className="font-mono text-[10px] text-slate-400">SOC2 Type II</span>
          </div>
        </div>
      </aside>
    </>
  );
};
