import React, { useState } from 'react';
import { 
  Search, 
  Bell, 
  Menu, 
  Check, 
  Sparkles, 
  AlertCircle,
  Database,
  UserCheck
} from 'lucide-react';
import { HindsightStatus } from '../types';

interface HeaderProps {
  onOpenMobileMenu: () => void;
  onOpenSearch: () => void;
  searchQuery?: string;
  onSearchChange?: (val: string) => void;
  onQuickNavigate?: (action: string) => void;
  hindsightStatus?: HindsightStatus;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenMobileMenu,
  onOpenSearch,
  hindsightStatus,
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      title: 'Memory Recall Triggered',
      desc: '3 historical memories matched Payment API timeout pattern',
      time: '2m ago',
      unread: true,
      icon: Sparkles,
      color: 'text-purple-400',
    },
    {
      id: 2,
      title: 'Incident INC-023 Resolved',
      desc: 'JWT cache invalidation completed and retained in memory',
      time: '18m ago',
      unread: false,
      icon: Check,
      color: 'text-emerald-400',
    },
    {
      id: 3,
      title: 'Hindsight Memory Synchronized',
      desc: hindsightStatus?.connected 
        ? `${hindsightStatus.count} real operational memories indexed in Bank: MemoryOps`
        : 'Running in local fallback mode (Hindsight Cloud Offline)',
      time: 'Just now',
      unread: false,
      icon: Database,
      color: 'text-blue-400',
    },
  ]);

  const unreadCount = notifications.filter((n) => n.unread).length;

  const markAllRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, unread: false })));
  };

  return (
    <header className="h-16 bg-[#0B1020]/95 backdrop-blur-md border-b border-slate-800/80 sticky top-0 z-30 px-4 sm:px-6 flex items-center justify-between gap-4">
      {/* Left: Mobile hamburger & Global Search Trigger */}
      <div className="flex items-center gap-3 flex-1 max-w-md">
        <button
          onClick={onOpenMobileMenu}
          className="p-2 -ml-2 text-slate-400 hover:text-white rounded-lg lg:hidden"
          aria-label="Open navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <button
          type="button"
          onClick={onOpenSearch}
          className="w-full flex items-center justify-between px-3.5 py-1.5 text-xs text-slate-400 bg-slate-900/80 hover:bg-slate-800/80 border border-slate-800 hover:border-slate-700 rounded-lg transition-colors group cursor-pointer shadow-xs"
        >
          <span className="flex items-center gap-2.5 truncate">
            <Search className="w-4 h-4 text-slate-500 group-hover:text-slate-300 shrink-0" />
            <span className="truncate">Search incidents, memories, root causes...</span>
          </span>
          <kbd className="hidden sm:inline-flex items-center gap-0.5 px-1.5 py-0.5 text-[10px] font-mono text-slate-400 bg-slate-800/80 border border-slate-700 rounded shrink-0">
            <span>⌘</span>K
          </kbd>
        </button>
      </div>

      {/* Right: Environment status, Notifications, User Profile */}
      <div className="flex items-center gap-3 sm:gap-4 shrink-0">
        {/* Status Indicator: Hindsight Cloud vs Local Fallback */}
        {hindsightStatus?.connected ? (
          <div className="hidden sm:flex items-center gap-2 px-2.5 py-1 rounded-full bg-purple-950/40 border border-purple-800/50 text-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-purple-300 font-medium text-[11px] tracking-wide">Hindsight Cloud Active</span>
          </div>
        ) : (
          <div 
            className="hidden sm:flex items-center gap-2 px-2.5 py-1 rounded-full bg-amber-950/40 border border-amber-800/50 text-xs"
            title={hindsightStatus?.error || 'HINDSIGHT_API_KEY not configured. Running in Local Fallback mode.'}
          >
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            <span className="text-amber-300 font-medium text-[11px] tracking-wide">Hindsight Cloud Offline</span>
          </div>
        )}

        {/* Notifications Icon with popover */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800/60 transition-colors relative"
            aria-label="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-purple-500 ring-2 ring-[#0B1020]" />
            )}
          </button>

          {showNotifications && (
            <>
              <div 
                className="fixed inset-0 z-30" 
                onClick={() => setShowNotifications(false)} 
              />
              <div className="absolute right-0 mt-2 w-80 sm:w-88 bg-[#111827] border border-slate-800 rounded-xl shadow-2xl z-40 overflow-hidden">
                <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
                  <div className="text-xs font-semibold text-white">Notifications</div>
                  {unreadCount > 0 && (
                    <button
                      onClick={markAllRead}
                      className="text-[11px] text-purple-400 hover:text-purple-300 font-medium"
                    >
                      Mark all as read
                    </button>
                  )}
                </div>

                <div className="divide-y divide-slate-800/60 max-h-80 overflow-y-auto">
                  {notifications.map((n) => {
                    const Icon = n.icon;
                    return (
                      <div
                        key={n.id}
                        className={`p-3.5 flex items-start gap-3 hover:bg-slate-800/40 transition-colors ${
                          n.unread ? 'bg-purple-950/20' : ''
                        }`}
                      >
                        <div className={`p-1.5 rounded-md bg-slate-800/80 ${n.color} shrink-0 mt-0.5`}>
                          <Icon className="w-3.5 h-3.5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-medium text-slate-200">{n.title}</div>
                          <div className="text-[11px] text-slate-400 mt-0.5 line-clamp-2">{n.desc}</div>
                          <div className="text-[10px] text-slate-500 mt-1 font-mono">{n.time}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="p-2 border-t border-slate-800 bg-slate-900/60 text-center">
                  <span className="text-[11px] text-slate-400">All notifications synced from Hindsight Engine</span>
                </div>
              </div>
            </>
          )}
        </div>

        {/* User avatar & name: Engineering Team */}
        <div className="flex items-center gap-2.5 pl-2 sm:pl-3 border-l border-slate-800">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-700 via-indigo-600 to-blue-500 flex items-center justify-center text-white text-xs font-semibold shadow-xs ring-1 ring-slate-700">
            ET
          </div>
          <div className="hidden md:block text-left">
            <div className="text-xs font-semibold text-slate-200 leading-tight">
              Engineering Team
            </div>
            <div className="text-[10px] text-slate-400 leading-tight flex items-center gap-1">
              <span className="text-emerald-400">●</span> SRE Lead
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
