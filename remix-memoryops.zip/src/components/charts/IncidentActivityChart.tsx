import React, { useState } from 'react';

interface DayData {
  day: string;
  count: number;
  short: string;
}

export const IncidentActivityChart: React.FC = () => {
  const [activeDay, setActiveDay] = useState<string | null>(null);

  const data: DayData[] = [
    { day: 'Monday', count: 3, short: 'Mon' },
    { day: 'Tuesday', count: 5, short: 'Tue' },
    { day: 'Wednesday', count: 2, short: 'Wed' },
    { day: 'Thursday', count: 6, short: 'Thu' },
    { day: 'Friday', count: 4, short: 'Fri' },
    { day: 'Saturday', count: 3, short: 'Sat' },
    { day: 'Sunday', count: 1, short: 'Sun' },
  ];

  const maxCount = 8; // headroom
  const total = data.reduce((acc, d) => acc + d.count, 24);

  return (
    <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between h-full">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-sm font-semibold text-slate-100 tracking-tight">Incident Activity</h2>
          <p className="text-xs text-slate-400 mt-0.5">Last 7 days incident occurrences</p>
        </div>
        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5 text-slate-300">
            <span className="w-2.5 h-2.5 rounded-sm bg-purple-500" />
            <span className="text-[11px] text-slate-400">Total: <strong className="text-slate-200 font-mono tabular-nums">24</strong></span>
          </div>
        </div>
      </div>

      {/* Bar visual with baseline and grid */}
      <div className="relative pt-6 pb-2">
        {/* Subtle grid lines */}
        <div className="absolute inset-x-0 top-6 bottom-8 flex flex-col justify-between pointer-events-none opacity-20">
          <div className="border-b border-slate-700 w-full" />
          <div className="border-b border-slate-700 w-full" />
          <div className="border-b border-slate-700 w-full" />
        </div>

        <div className="grid grid-cols-7 gap-2 sm:gap-3 items-end h-36 z-10 relative">
          {data.map((item) => {
            const heightPercent = Math.round((item.count / maxCount) * 100);
            const isHovered = activeDay === item.day;
            const isPeak = item.count === 6;

            return (
              <div
                key={item.day}
                onMouseEnter={() => setActiveDay(item.day)}
                onMouseLeave={() => setActiveDay(null)}
                className="flex flex-col items-center h-full justify-end group cursor-pointer"
              >
                {/* Tooltip on hover */}
                <div
                  className={`text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-purple-300 mb-1 border border-slate-700 transition-opacity duration-150 whitespace-nowrap ${
                    isHovered ? 'opacity-100 scale-105' : 'opacity-0 group-hover:opacity-100'
                  }`}
                >
                  {item.count} {item.count === 1 ? 'inc' : 'incs'}
                </div>

                {/* Bar */}
                <div className="w-full max-w-[28px] bg-slate-800/80 rounded-t-sm h-full flex items-end overflow-hidden p-0.5">
                  <div
                    style={{ height: `${heightPercent}%` }}
                    className={`w-full rounded-t-sm transition-all duration-300 ${
                      isPeak
                        ? 'bg-gradient-to-t from-purple-700 to-purple-400 shadow-md shadow-purple-900/40'
                        : isHovered
                        ? 'bg-purple-400'
                        : 'bg-purple-600/80 group-hover:bg-purple-500'
                    }`}
                  />
                </div>

                {/* Day label */}
                <span className="text-[11px] font-medium text-slate-400 mt-2 group-hover:text-slate-200 transition-colors">
                  {item.short}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
        <span>Peak activity on <strong className="text-slate-300 font-medium">Thursday (6)</strong></span>
        <span className="font-mono text-emerald-400 tabular-nums">Avg 3.4 / day</span>
      </div>
    </div>
  );
};
