import React, { useState } from 'react';

interface SeveritySlice {
  label: string;
  count: number;
  color: string;
  hoverColor: string;
  bgColor: string;
  textColor: string;
}

export const SeverityDonutChart: React.FC = () => {
  const [hovered, setHovered] = useState<string | null>(null);

  const slices: SeveritySlice[] = [
    { label: 'Critical', count: 4, color: '#EF4444', hoverColor: '#F87171', bgColor: 'bg-red-500/10', textColor: 'text-red-400' },
    { label: 'High', count: 8, color: '#F59E0B', hoverColor: '#FBBF24', bgColor: 'bg-amber-500/10', textColor: 'text-amber-400' },
    { label: 'Medium', count: 9, color: '#3B82F6', hoverColor: '#60A5FA', bgColor: 'bg-blue-500/10', textColor: 'text-blue-400' },
    { label: 'Low', count: 3, color: '#22C55E', hoverColor: '#4ADE80', bgColor: 'bg-emerald-500/10', textColor: 'text-emerald-400' },
  ];

  const total = slices.reduce((acc, s) => acc + s.count, 0); // 24

  // Calculate SVG stroke dashes
  // Circumference = 2 * PI * r
  const r = 40;
  const circumference = 2 * Math.PI * r;

  let cumulativeOffset = 0;
  const segments = slices.map((slice) => {
    const strokeDasharray = (slice.count / total) * circumference;
    const strokeDashoffset = -cumulativeOffset;
    cumulativeOffset += strokeDasharray;
    const percentage = Math.round((slice.count / total) * 100);
    return {
      ...slice,
      strokeDasharray: `${strokeDasharray} ${circumference}`,
      strokeDashoffset,
      percentage,
    };
  });

  const activeSlice = hovered ? slices.find((s) => s.label === hovered) : null;

  return (
    <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between h-full">
      <div className="flex items-center justify-between mb-2">
        <div>
          <h2 className="text-sm font-semibold text-slate-100 tracking-tight">Severity Distribution</h2>
          <p className="text-xs text-slate-400 mt-0.5">Active & historical severity breakdown</p>
        </div>
        <span className="text-[11px] font-mono text-slate-400 px-2 py-0.5 bg-slate-800/80 rounded border border-slate-700/60">
          24 Total
        </span>
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-around gap-4 my-2">
        {/* SVG Donut */}
        <div className="relative w-36 h-36 shrink-0 flex items-center justify-center">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
            {/* Background ring */}
            <circle
              cx="50"
              cy="50"
              r={r}
              className="text-slate-800/80 stroke-current"
              strokeWidth="14"
              fill="transparent"
            />
            {/* Segments */}
            {segments.map((seg) => (
              <circle
                key={seg.label}
                cx="50"
                cy="50"
                r={r}
                stroke={hovered === seg.label ? seg.hoverColor : seg.color}
                strokeWidth={hovered === seg.label ? '17' : '14'}
                strokeDasharray={seg.strokeDasharray}
                strokeDashoffset={seg.strokeDashoffset}
                strokeLinecap="butt"
                fill="transparent"
                className="transition-all duration-200 cursor-pointer"
                onMouseEnter={() => setHovered(seg.label)}
                onMouseLeave={() => setHovered(null)}
              />
            ))}
          </svg>

          {/* Center Callout */}
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
            {activeSlice ? (
              <>
                <span className="text-xs font-semibold text-slate-300">{activeSlice.label}</span>
                <span className="text-base font-bold text-white font-mono tabular-nums leading-none mt-0.5">
                  {activeSlice.count}
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  {Math.round((activeSlice.count / total) * 100)}%
                </span>
              </>
            ) : (
              <>
                <span className="text-[10px] uppercase tracking-wider text-slate-400">Total</span>
                <span className="text-lg font-bold text-white font-mono tabular-nums leading-none">24</span>
                <span className="text-[10px] text-slate-400">incidents</span>
              </>
            )}
          </div>
        </div>

        {/* Legend List */}
        <div className="grid grid-cols-2 sm:grid-cols-1 gap-2 w-full max-w-[180px]">
          {segments.map((s) => (
            <div
              key={s.label}
              onMouseEnter={() => setHovered(s.label)}
              onMouseLeave={() => setHovered(null)}
              className={`flex items-center justify-between p-1.5 rounded-lg border transition-colors cursor-pointer ${
                hovered === s.label
                  ? 'bg-slate-800/80 border-slate-700'
                  : 'border-transparent hover:bg-slate-800/40'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: s.color }} />
                <span className="text-xs text-slate-300 font-medium">{s.label}</span>
              </div>
              <div className="flex items-center gap-1.5 font-mono text-xs tabular-nums">
                <span className="font-semibold text-slate-200">{s.count}</span>
                <span className="text-[10px] text-slate-400">({s.percentage}%)</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
        <span>Critical threshold: <strong className="text-red-400 font-medium">16.7%</strong></span>
        <span className="text-slate-400">Prioritize Sev 1</span>
      </div>
    </div>
  );
};
