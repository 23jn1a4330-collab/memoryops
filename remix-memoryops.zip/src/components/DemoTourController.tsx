import React, { useEffect } from 'react';
import { Play, Pause, SkipForward, X, Sparkles, CheckCircle2, FastForward } from 'lucide-react';

export interface DemoStep {
  id: number;
  label: string;
  durationMs: number;
  action: () => void;
}

interface DemoTourControllerProps {
  isRunning: boolean;
  isPaused: boolean;
  currentStepIndex: number;
  totalSteps: number;
  currentStepLabel: string;
  onPauseToggle: () => void;
  onNextStep: () => void;
  onExit: () => void;
}

export const DemoTourController: React.FC<DemoTourControllerProps> = ({
  isRunning,
  isPaused,
  currentStepIndex,
  totalSteps,
  currentStepLabel,
  onPauseToggle,
  onNextStep,
  onExit,
}) => {
  if (!isRunning) return null;

  const progressPercent = Math.round(((currentStepIndex + 1) / totalSteps) * 100);

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 w-full max-w-xl px-4 animate-in slide-in-from-bottom-4 duration-300">
      <div className="bg-[#111827]/95 border-2 border-purple-500/80 rounded-2xl p-4 shadow-2xl shadow-purple-950/70 backdrop-blur-md">
        {/* Top bar with badge and exit */}
        <div className="flex items-center justify-between gap-3 mb-2">
          <div className="flex items-center gap-2">
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-purple-500"></span>
            </span>
            <span className="text-xs font-semibold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              Automated Memory Demo Tour
            </span>
            <span className="text-[11px] font-mono text-slate-400 px-2 py-0.5 rounded bg-slate-800 border border-slate-700">
              Step {currentStepIndex + 1} of {totalSteps}
            </span>
          </div>

          <button
            onClick={onExit}
            className="p-1 text-slate-400 hover:text-white rounded-md hover:bg-slate-800 transition-colors"
            title="Stop Demo Tour"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Step description */}
        <div className="text-sm font-medium text-white mb-3 truncate flex items-center gap-2">
          <span className="text-purple-400">→</span>
          <span>{currentStepLabel}</span>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-slate-800 rounded-full h-1.5 mb-3 overflow-hidden">
          <div
            className="bg-gradient-to-r from-purple-500 via-indigo-400 to-emerald-400 h-1.5 transition-all duration-300 rounded-full"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Controls */}
        <div className="flex items-center justify-between text-xs">
          <div className="text-[11px] text-slate-400">
            {isPaused ? (
              <span className="text-amber-400 font-medium">Tour paused</span>
            ) : (
              <span>Auto-playing sequence...</span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onPauseToggle}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium flex items-center gap-1.5 transition-colors border border-slate-700"
            >
              {isPaused ? (
                <>
                  <Play className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400" />
                  <span>Resume</span>
                </>
              ) : (
                <>
                  <Pause className="w-3.5 h-3.5 text-amber-400" />
                  <span>Pause</span>
                </>
              )}
            </button>

            <button
              onClick={onNextStep}
              className="px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-medium flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <span>Next</span>
              <SkipForward className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
