import React, { useState } from 'react';
import { X, CheckCircle, BrainCircuit, ShieldAlert, Sparkles } from 'lucide-react';
import { Incident } from '../../types';

interface ResolveIncidentModalProps {
  isOpen: boolean;
  incident: Incident | null;
  onClose: () => void;
  onResolveAndRemember: (data: {
    rootCause: string;
    resolution: string;
    outcome: string;
  }) => void;
}

export const ResolveIncidentModal: React.FC<ResolveIncidentModalProps> = ({
  isOpen,
  incident,
  onClose,
  onResolveAndRemember,
}) => {
  const [rootCause, setRootCause] = useState('Database connection pool exhaustion.');
  const [resolution, setResolution] = useState(
    'Increased database connection pool from 20 to 50 and restarted the affected service.'
  );
  const [outcome, setOutcome] = useState('Incident resolved successfully.');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onResolveAndRemember({
      rootCause,
      resolution,
      outcome,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-[#111827] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-4.5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <CheckCircle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white tracking-tight">Resolve Incident</h3>
              <p className="text-xs text-slate-400">
                {incident?.id || 'INC-025'} · {incident?.service || 'Payment API'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Root Cause
            </label>
            <input
              type="text"
              value={rootCause}
              onChange={(e) => setRootCause(e.target.value)}
              required
              className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-hidden focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
              placeholder="e.g. Connection pool exhaustion"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Resolution
            </label>
            <textarea
              rows={3}
              value={resolution}
              onChange={(e) => setResolution(e.target.value)}
              required
              className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-hidden focus:border-purple-500 focus:ring-1 focus:ring-purple-500 resize-none font-sans"
              placeholder="Detail the operational steps taken..."
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Outcome
            </label>
            <input
              type="text"
              value={outcome}
              onChange={(e) => setOutcome(e.target.value)}
              required
              className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-hidden focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
              placeholder="e.g. Resolved successfully"
            />
          </div>

          {/* Memory Learning Retention Pipeline Preview */}
          <div className="p-3.5 rounded-xl bg-purple-950/30 border border-purple-800/50 space-y-2">
            <div className="flex items-center justify-between text-[11px] font-mono">
              <span className="text-purple-300 font-bold uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                Memory Learning Sequence
              </span>
              <span className="text-emerald-400 font-medium">Stage 5 → Stage 6</span>
            </div>

            <div className="grid grid-cols-3 gap-1.5 text-[10px] font-mono pt-1">
              <div className="p-1.5 rounded bg-slate-900 border border-slate-800 text-center">
                <div className="text-slate-400">Stages 1-4</div>
                <div className="text-blue-300 font-semibold">Applied</div>
              </div>
              <div className="p-1.5 rounded bg-purple-950/60 border border-purple-700/60 text-center">
                <div className="text-purple-300">5. Resolve</div>
                <div className="text-emerald-400 font-bold">→ Resolved</div>
              </div>
              <div className="p-1.5 rounded bg-emerald-950/60 border border-emerald-700/60 text-center">
                <div className="text-emerald-300">6. Retain</div>
                <div className="text-emerald-400 font-bold">→ Retained</div>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed pt-1">
              <strong className="text-white font-medium">Continuous Learning:</strong> MemoryOps will commit this verified fix into Hindsight Cloud (Bank: MemoryOps) to continuously improve future incident responses.
            </p>
          </div>

          {/* Footer Actions */}
          <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 rounded-lg shadow-md shadow-emerald-950/50 flex items-center gap-2 transition-all transform active:scale-98 cursor-pointer"
            >
              <BrainCircuit className="w-4 h-4" />
              <span>Resolve & Remember</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
