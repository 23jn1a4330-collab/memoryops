import React, { useState, useEffect } from 'react';
import { Search, X, AlertTriangle, Database, ArrowRight, CornerDownLeft } from 'lucide-react';
import { Incident, MemoryItem } from '../../types';
import { PageId } from '../Sidebar';

interface QuickSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  incidents: Incident[];
  memories: MemoryItem[];
  onSelectIncident: (inc: Incident) => void;
  onSelectMemory: (mem: MemoryItem) => void;
  onNavigate: (page: PageId) => void;
}

export const QuickSearchModal: React.FC<QuickSearchModalProps> = ({
  isOpen,
  onClose,
  incidents,
  memories,
  onSelectIncident,
  onSelectMemory,
  onNavigate,
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      } else if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const filteredIncidents = query.trim()
    ? incidents.filter(
        (i) =>
          i.title.toLowerCase().includes(query.toLowerCase()) ||
          i.id.toLowerCase().includes(query.toLowerCase()) ||
          i.service.toLowerCase().includes(query.toLowerCase()) ||
          i.rootCause?.toLowerCase().includes(query.toLowerCase())
      )
    : incidents.slice(0, 4);

  const filteredMemories = query.trim()
    ? memories.filter(
        (m) =>
          m.title.toLowerCase().includes(query.toLowerCase()) ||
          m.service.toLowerCase().includes(query.toLowerCase()) ||
          m.rootCause.toLowerCase().includes(query.toLowerCase()) ||
          m.tags.some((t) => t.toLowerCase().includes(query.toLowerCase()))
      )
    : memories.slice(0, 3);

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-2xl bg-[#111827] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Search Input Bar */}
        <div className="p-4 border-b border-slate-800 flex items-center gap-3 bg-slate-900/60">
          <Search className="w-5 h-5 text-purple-400 shrink-0" />
          <input
            autoFocus
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search incidents, operational memories, root causes..."
            className="w-full bg-transparent text-sm text-white placeholder-slate-500 focus:outline-hidden"
          />
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-md transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-[60vh] overflow-y-auto p-3 space-y-4">
          {/* Quick Action Navigation */}
          {!query && (
            <div className="px-3 py-1.5 flex items-center gap-2 overflow-x-auto text-xs text-slate-400 border-b border-slate-800/60 pb-3">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Quick Links:</span>
              <button
                onClick={() => { onNavigate('dashboard'); onClose(); }}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              >
                Dashboard
              </button>
              <button
                onClick={() => { onNavigate('new-incident'); onClose(); }}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              >
                + New Incident
              </button>
              <button
                onClick={() => { onNavigate('memory-explorer'); onClose(); }}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              >
                Memory Explorer
              </button>
            </div>
          )}

          {/* Incidents Section */}
          <div>
            <div className="px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-slate-400 flex items-center justify-between">
              <span>Incidents ({filteredIncidents.length})</span>
              <span className="text-slate-400 font-normal">Click to view details</span>
            </div>
            {filteredIncidents.length === 0 ? (
              <div className="p-3 text-xs text-slate-500 italic">No incidents match "{query}"</div>
            ) : (
              <div className="space-y-1 mt-1">
                {filteredIncidents.map((inc) => (
                  <button
                    key={inc.id}
                    onClick={() => {
                      onSelectIncident(inc);
                      onClose();
                    }}
                    className="w-full text-left p-2.5 rounded-lg hover:bg-slate-800/60 transition-colors flex items-center justify-between group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="p-1.5 rounded-md bg-slate-800 text-slate-400 group-hover:text-purple-300 shrink-0">
                        <AlertTriangle className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-slate-200 truncate group-hover:text-white">
                          <span className="text-purple-400 font-mono mr-1.5">{inc.id}</span>
                          {inc.title}
                        </div>
                        <div className="text-[11px] text-slate-400 truncate mt-0.5">
                          {inc.service} · {inc.severity} · {inc.status}
                        </div>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity shrink-0 ml-2" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Memories Section */}
          <div>
            <div className="px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-slate-400 flex items-center justify-between">
              <span>Hindsight Memories ({filteredMemories.length})</span>
              <span className="text-slate-400 font-normal">Historical operational records</span>
            </div>
            {filteredMemories.length === 0 ? (
              <div className="p-3 text-xs text-slate-500 italic">No memories match "{query}"</div>
            ) : (
              <div className="space-y-1 mt-1">
                {filteredMemories.map((mem) => (
                  <button
                    key={mem.id}
                    onClick={() => {
                      onSelectMemory(mem);
                      onClose();
                    }}
                    className="w-full text-left p-2.5 rounded-lg hover:bg-slate-800/60 transition-colors flex items-center justify-between group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="p-1.5 rounded-md bg-purple-950/40 text-purple-400 border border-purple-800/40 shrink-0">
                        <Database className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-slate-200 truncate group-hover:text-purple-200">
                          {mem.title}
                        </div>
                        <div className="text-[11px] text-slate-400 truncate mt-0.5">
                          {mem.service} · Cause: <span className="text-slate-300">{mem.rootCause}</span>
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 shrink-0 ml-2">
                      {mem.relevance}% match
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer Shortcut tips */}
        <div className="p-3 bg-slate-900/80 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
          <div className="flex items-center gap-3">
            <span>Type to search</span>
            <span>·</span>
            <span>ESC to close</span>
          </div>
          <div className="flex items-center gap-1 font-mono text-[10px]">
            <CornerDownLeft className="w-3 h-3 text-slate-400" />
            <span>Select</span>
          </div>
        </div>
      </div>
    </div>
  );
};
