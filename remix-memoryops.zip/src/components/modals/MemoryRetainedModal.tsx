import React from 'react';
import { CheckCircle2, BrainCircuit, ArrowDown, Sparkles, X, ChevronRight, Check, TrendingUp, ArrowRight, Zap, ShieldCheck } from 'lucide-react';
import { Incident } from '../../types';

interface MemoryRetainedModalProps {
  isOpen: boolean;
  incident: Incident | null;
  rootCause: string;
  resolution: string;
  outcome: string;
  onClose: () => void;
  onViewMemory: () => void;
}

export const MemoryRetainedModal: React.FC<MemoryRetainedModalProps> = ({
  isOpen,
  incident,
  rootCause,
  resolution,
  outcome,
  onClose,
  onViewMemory,
}) => {
  if (!isOpen) return null;

  const steps = [
    { num: 1, title: 'INCIDENT RECEIVED', status: 'Applied', detail: `${incident?.id || 'INC-025'} · ${incident?.service || 'Payment API'}` },
    { num: 2, title: 'HINDSIGHT RECALL', status: 'Found', detail: 'Hindsight Cloud (Bank: MemoryOps)' },
    { num: 3, title: 'HISTORICAL MEMORY FOUND', status: 'Found', detail: 'Incident #017 (96% Match)' },
    { num: 4, title: 'AI USES MEMORY', status: 'Applied', detail: 'Pool capacity scaled 20 → 50' },
    { num: 5, title: 'INCIDENT RESOLVED', status: 'Resolved', detail: 'Verified resolution applied' },
    { num: 6, title: 'NEW MEMORY RETAINED', status: 'Retained', detail: 'Committed into Hindsight Cloud' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-[#111827] border-2 border-emerald-500/60 rounded-2xl shadow-2xl shadow-emerald-950/50 overflow-hidden flex flex-col">
        {/* Top Header */}
        <div className="p-6 text-center border-b border-slate-800 bg-gradient-to-b from-emerald-950/40 via-purple-950/20 to-transparent relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-14 h-14 mx-auto rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center mb-3 shadow-lg shadow-emerald-950/40 animate-in zoom-in-50 duration-300">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <div className="flex items-center justify-center gap-1.5 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-1">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>Memory Learning Complete</span>
          </div>

          <div className="text-2xl font-bold text-white tracking-tight">
            Memory learned successfully
          </div>

          <p className="text-sm text-emerald-200/90 mt-2 max-w-lg mx-auto leading-relaxed font-medium">
            This incident has been retained in Hindsight and can improve future incident responses.
          </p>
        </div>

        {/* 6-Step Visual Sequence */}
        <div className="p-6 bg-slate-950/50 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">
              Memory Learning Sequence
            </span>
            <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 px-2.5 py-0.5 rounded border border-emerald-800/60">
              All 6 Stages Completed
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {steps.map((s) => (
              <div
                key={s.num}
                className="p-3 rounded-xl border border-slate-800 bg-slate-900/90 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[10px] font-mono text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded">
                      Step {s.num}
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                        s.status === 'Retained'
                          ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-400'
                          : s.status === 'Resolved'
                          ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-600/50'
                          : s.status === 'Applied'
                          ? 'bg-blue-950/60 text-blue-300 border border-blue-600/50'
                          : 'bg-purple-950/60 text-purple-300 border border-purple-600/50'
                      }`}
                    >
                      {s.status}
                    </span>
                  </div>
                  <div className="text-xs font-bold text-white tracking-tight">{s.title}</div>
                  <div className="text-[11px] text-slate-400 truncate mt-0.5">{s.detail}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Retention Details summary */}
          <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-slate-400">Target Memory Bank:</span>
              <span className="font-mono text-purple-300 font-semibold">Hindsight Cloud / MemoryOps</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Verified Resolution Stored:</span>
              <span className="text-slate-200 font-medium truncate max-w-[320px]">
                {resolution || 'Increased pool from 20 to 50'}
              </span>
            </div>
          </div>

          {/* Visual proof that agent is learning over time */}
          <div className="p-3.5 rounded-xl bg-gradient-to-r from-purple-950/40 via-slate-900 to-emerald-950/40 border border-purple-600/40">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
                Agent Knowledge Compounding Over Time
              </span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed mb-3">
              With each resolution, the agent autonomously expands its operational knowledge. Future payment outages will automatically correlate with this resolved experience.
            </p>

            <div className="flex items-center justify-between bg-slate-950/70 p-2.5 rounded-lg border border-slate-800 text-[11px]">
              <div className="text-center">
                <span className="text-slate-400 block text-[10px]">Baseline</span>
                <span className="font-semibold text-slate-300">Incident #017</span>
              </div>
              <ArrowRight className="w-3.5 h-3.5 text-purple-400" />
              <div className="text-center">
                <span className="text-purple-400 block text-[10px]">Today</span>
                <span className="font-bold text-white">{incident?.id || 'INC-025'} Learned</span>
              </div>
              <ArrowRight className="w-3.5 h-3.5 text-emerald-400" />
              <div className="text-center">
                <span className="text-emerald-400 block text-[10px]">Future Incidents</span>
                <span className="font-bold text-emerald-300">Instant Recall</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/90 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            Dismiss
          </button>
          <button
            onClick={onViewMemory}
            className="px-5 py-2.5 text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-purple-600 to-emerald-600 hover:from-purple-500 hover:to-emerald-500 rounded-lg shadow-md shadow-emerald-950/40 flex items-center gap-2 transition-transform active:scale-98 cursor-pointer"
          >
            <BrainCircuit className="w-4 h-4" />
            <span>View in Memory Explorer</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
