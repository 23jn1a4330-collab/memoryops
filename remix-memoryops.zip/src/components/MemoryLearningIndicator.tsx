import React from 'react';
import { 
  BrainCircuit, 
  Sparkles, 
  CheckCircle2, 
  Search, 
  Database, 
  ArrowRight, 
  Clock, 
  TrendingUp, 
  Check, 
  Layers,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { Incident, HindsightStatus, MemoryItem } from '../types';

export type MemoryLearningState = 'Pending' | 'Searching' | 'Found' | 'Applied' | 'Resolved' | 'Retained';

interface StepConfig {
  number: number;
  title: string;
  detail: string;
  status: MemoryLearningState;
}

interface MemoryLearningIndicatorProps {
  currentIncident: Incident;
  hindsightStatus?: HindsightStatus;
  recalledMemory?: MemoryItem | null;
  isResolved?: boolean;
  isRetained?: boolean;
  isSearching?: boolean;
  className?: string;
  compact?: boolean;
}

export const MemoryLearningIndicator: React.FC<MemoryLearningIndicatorProps> = ({
  currentIncident,
  hindsightStatus,
  recalledMemory,
  isResolved = false,
  isRetained = false,
  isSearching = false,
  className = '',
  compact = false,
}) => {
  const resolved = isResolved || currentIncident.status === 'Resolved' || currentIncident.memoryStatus === 'Retained';
  const retained = isRetained || currentIncident.memoryStatus === 'Retained' || resolved;

  // Derive status for each of the 6 visual stages:
  // 1. INCIDENT RECEIVED -> Applied (Active in operational context)
  // 2. HINDSIGHT RECALL -> Searching (during query) or Found
  // 3. HISTORICAL MEMORY FOUND -> Found (Incident #017 retrieved)
  // 4. AI USES MEMORY -> Applied (Recommendation grounded on previous resolution)
  // 5. INCIDENT RESOLVED -> Resolved (if resolved) or Pending
  // 6. NEW MEMORY RETAINED -> Retained (if retained) or Pending
  const steps: StepConfig[] = [
    {
      number: 1,
      title: 'INCIDENT RECEIVED',
      detail: `${currentIncident.id || 'INC-025'} · ${currentIncident.service}`,
      status: 'Applied',
    },
    {
      number: 2,
      title: 'HINDSIGHT RECALL',
      detail: hindsightStatus?.connected ? 'Hindsight Cloud (Bank: MemoryOps)' : 'Vector Query Engine',
      status: isSearching ? 'Searching' : 'Found',
    },
    {
      number: 3,
      title: 'HISTORICAL MEMORY FOUND',
      detail: recalledMemory ? `${recalledMemory.incidentId} (${recalledMemory.relevance}% Match)` : 'Incident #017 (96% Match)',
      status: isSearching ? 'Searching' : 'Found',
    },
    {
      number: 4,
      title: 'AI USES MEMORY',
      detail: 'Grounded on verified pool scaling fix',
      status: isSearching ? 'Pending' : 'Applied',
    },
    {
      number: 5,
      title: 'INCIDENT RESOLVED',
      detail: resolved ? 'Applied verified fix (Pool 20 → 50)' : 'Awaiting resolution confirmation',
      status: resolved ? 'Resolved' : 'Pending',
    },
    {
      number: 6,
      title: 'NEW MEMORY RETAINED',
      detail: retained ? 'Committed to Hindsight Bank' : 'Will index upon resolution',
      status: retained ? 'Retained' : 'Pending',
    },
  ];

  const renderStatusBadge = (status: MemoryLearningState) => {
    switch (status) {
      case 'Pending':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-800 text-slate-400 border border-slate-700/80 uppercase tracking-wide">
            <span className="w-1.5 h-1.5 rounded-full bg-slate-500" />
            Pending
          </span>
        );
      case 'Searching':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-950/60 text-amber-300 border border-amber-600/50 uppercase tracking-wide animate-pulse">
            <Search className="w-3 h-3 text-amber-400 animate-spin" />
            Searching
          </span>
        );
      case 'Found':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-purple-950/70 text-purple-300 border border-purple-500/60 uppercase tracking-wide">
            <Sparkles className="w-3 h-3 text-purple-400" />
            Found
          </span>
        );
      case 'Applied':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-blue-950/70 text-blue-300 border border-blue-500/60 uppercase tracking-wide">
            <Zap className="w-3 h-3 text-blue-400" />
            Applied
          </span>
        );
      case 'Resolved':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-950/80 text-emerald-300 border border-emerald-500/60 uppercase tracking-wide">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            Resolved
          </span>
        );
      case 'Retained':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-gradient-to-r from-emerald-950/80 to-purple-950/80 text-emerald-300 border border-emerald-400/80 uppercase tracking-wide shadow-sm shadow-emerald-950/40">
            <BrainCircuit className="w-3 h-3 text-emerald-400" />
            Retained
          </span>
        );
    }
  };

  const getStepBorderClass = (status: MemoryLearningState) => {
    switch (status) {
      case 'Retained':
        return 'border-emerald-500/80 bg-gradient-to-b from-emerald-950/30 to-slate-900 shadow-md shadow-emerald-950/30';
      case 'Resolved':
        return 'border-emerald-500/60 bg-emerald-950/20';
      case 'Applied':
        return 'border-blue-500/50 bg-blue-950/15';
      case 'Found':
        return 'border-purple-500/60 bg-purple-950/20';
      case 'Searching':
        return 'border-amber-500/60 bg-amber-950/20 animate-pulse';
      case 'Pending':
      default:
        return 'border-slate-800 bg-slate-900/60 opacity-75';
    }
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* SUCCESS BANNER: Displayed when Resolve & Remember succeeds */}
      {resolved && (
        <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-purple-950/50 border-2 border-emerald-500/80 shadow-2xl shadow-emerald-950/50 animate-in fade-in zoom-in-95 duration-300">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start sm:items-center gap-3.5">
              <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shrink-0 shadow-lg shadow-emerald-950/40">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-lg sm:text-xl font-bold text-white tracking-tight">
                    Memory learned successfully
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[10px] font-mono font-bold uppercase tracking-wider">
                    Bank: MemoryOps
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-emerald-200/90 mt-1 font-medium">
                  This incident has been retained in Hindsight and can improve future incident responses.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2.5 shrink-0 self-start sm:self-auto pl-12 sm:pl-0">
              <span className="text-xs font-mono font-semibold text-purple-300 bg-purple-950/60 px-3 py-1.5 rounded-lg border border-purple-700/60 flex items-center gap-1.5">
                <BrainCircuit className="w-3.5 h-3.5 text-purple-400" />
                {hindsightStatus?.count ? `${hindsightStatus.count} Memories Indexed` : 'Continuous Learning Active'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* MAIN MEMORY LEARNING SEQUENCE CARD */}
      <div className="bg-[#111827] border border-purple-500/40 rounded-2xl p-5 sm:p-6 shadow-xl shadow-purple-950/20 relative overflow-hidden">
        {/* Header bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800 mb-5">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-600/20 border border-purple-500/40 text-purple-300">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-purple-400 font-mono">
                  Memory Learning Flow
                </span>
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-bold text-white tracking-tight">
                AI Incident Resolution & Memory Lifecycle
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-slate-400 bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800">
              Target: <strong className="text-purple-300 font-semibold">{hindsightStatus?.bankId || 'MemoryOps'}</strong>
            </span>
            <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/50 px-2.5 py-1 rounded-lg border border-emerald-800/60">
              {resolved ? 'Status: Retained' : 'Status: AI Grounded'}
            </span>
          </div>
        </div>

        {/* The 6-Step Visual Sequence */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
          {steps.map((step, idx) => (
            <div
              key={step.number}
              className={`p-3.5 rounded-xl border flex flex-col justify-between transition-all duration-200 relative ${getStepBorderClass(
                step.status
              )}`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-300 font-mono text-[10px] font-bold flex items-center justify-center border border-slate-700">
                    {step.number}
                  </span>
                  {renderStatusBadge(step.status)}
                </div>

                <div className="text-xs font-bold text-white tracking-tight mb-1">
                  {step.title}
                </div>

                <div className="text-[11px] text-slate-400 leading-tight">
                  {step.detail}
                </div>
              </div>

              {/* Progress connector indicator */}
              <div className="mt-3 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[10px] font-mono">
                <span className="text-slate-500">Step {step.number} of 6</span>
                {step.status === 'Retained' || step.status === 'Resolved' ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : step.status === 'Applied' ? (
                  <Check className="w-3.5 h-3.5 text-blue-400" />
                ) : step.status === 'Found' ? (
                  <Check className="w-3.5 h-3.5 text-purple-400" />
                ) : step.status === 'Searching' ? (
                  <span className="text-amber-400 font-bold">...</span>
                ) : (
                  <span className="text-slate-600">○</span>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* AGENT IS LEARNING OVER TIME: Visual knowledge compounding representation */}
        {!compact && (
          <div className="mt-5 pt-4 border-t border-slate-800/80 bg-slate-950/40 -mx-5 -mb-5 sm:-mx-6 sm:-mb-6 p-4 sm:p-5 rounded-b-2xl">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-purple-400" />
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                    Agent Learning Over Time
                  </span>
                  <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/50">
                    Continuous SRE Loop
                  </span>
                </div>
                <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
                  Every incident resolution is synthesized and committed to Hindsight Cloud. Future database connection timeouts will automatically recall both <strong className="text-purple-300 font-semibold">Incident #017</strong> and <strong className="text-white font-semibold">{currentIncident.id || 'Incident #025'}</strong> to eliminate diagnostic latency.
                </p>
              </div>

              {/* Timeline nodes showing learning over time */}
              <div className="flex items-center gap-2 self-start md:self-auto shrink-0 bg-slate-900/90 p-2.5 rounded-xl border border-slate-800">
                <div className="text-center px-2">
                  <div className="text-[10px] font-mono text-slate-400">Sep 27</div>
                  <div className="text-xs font-bold text-slate-300">#017</div>
                  <div className="text-[9px] text-purple-400 font-medium">Pool: 50</div>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-slate-600" />
                <div className="text-center px-2">
                  <div className="text-[10px] font-mono text-purple-400">Today</div>
                  <div className="text-xs font-bold text-purple-300">#025</div>
                  <div className="text-[9px] text-blue-400 font-medium">Recalled</div>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-slate-600" />
                <div className="text-center px-2 bg-purple-950/40 rounded-lg py-1 border border-purple-800/40">
                  <div className="text-[10px] font-mono text-emerald-400">Future</div>
                  <div className="text-xs font-bold text-emerald-300">Auto-Fix</div>
                  <div className="text-[9px] text-emerald-400 font-medium">Zero MTTR</div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
