import { Incident, SeverityLevel, Environment, ServiceName } from '../types';
import { SEEDED_INCIDENTS } from '../data/seedData';

// Local storage key for persistent demo state within browser session
const STORAGE_KEY = 'memoryops_incidents_state';

class IncidentService {
  private incidents: Incident[] = [];

  constructor() {
    this.init();
  }

  private init() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        this.incidents = JSON.parse(saved);
        return;
      } catch (e) {
        console.warn('Failed to load incidents from localStorage, resetting to seed', e);
      }
    }
    this.incidents = [...SEEDED_INCIDENTS];
    this.save();
  }

  private save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.incidents));
    } catch (e) {
      console.warn('Failed to persist incidents', e);
    }
  }

  public getIncidents(): Incident[] {
    return [...this.incidents];
  }

  public getIncident(id: string): Incident | undefined {
    return this.incidents.find((i) => i.id.toLowerCase() === id.toLowerCase());
  }

  public getRecentIncidents(limit = 5): Incident[] {
    return this.incidents.slice(0, limit);
  }

  public createIncident(data: {
    service: ServiceName;
    incidentType?: string;
    title: string;
    severity: SeverityLevel;
    description: string;
    logs: string;
    environment: Environment;
  }): Incident {
    // Generate next ID
    const currentMax = this.incidents.reduce((max, inc) => {
      const num = parseInt(inc.id.replace('INC-', ''), 10);
      return !isNaN(num) && num > max ? num : max;
    }, 24);

    const nextId = `INC-0${currentMax + 1}`;
    const newIncident: Incident = {
      id: nextId,
      service: data.service,
      incidentType: data.incidentType || 'Database Connection Timeout',
      title: data.title,
      severity: data.severity,
      status: 'Investigating',
      environment: data.environment,
      description: data.description,
      logs: data.logs,
      date: 'Sep 28',
      memoriesCount: 3,
      memoryStatus: 'Pending',
      relatedIncidents: ['INC-017', 'INC-011', 'INC-004'],
      timeline: [
        { time: 'Just now', event: 'Incident registered and ingested into MemoryOps', actor: 'Engineering Team' },
        { time: 'Just now', event: 'Hindsight recall triggered: searching historical operational memory', actor: 'MemoryOps Agent' },
      ],
    };

    this.incidents = [newIncident, ...this.incidents];
    this.save();
    return newIncident;
  }

  public resolveIncident(
    id: string,
    rootCause: string,
    resolution: string,
    outcome: string
  ): Incident | undefined {
    const index = this.incidents.findIndex((i) => i.id === id);
    if (index === -1) return undefined;

    const updated: Incident = {
      ...this.incidents[index],
      status: 'Resolved',
      rootCause,
      resolution,
      outcome,
      memoryStatus: 'Retained',
    };

    this.incidents[index] = updated;
    this.save();
    return updated;
  }

  public getStats() {
    const total = this.incidents.length;
    const critical = this.incidents.filter((i) => i.severity === 'Critical').length;
    const resolved = this.incidents.filter((i) => i.status === 'Resolved').length;
    const resolutionRate = total > 0 ? Math.round((resolved / total) * 100) : 83;

    return {
      total,
      critical,
      resolved,
      resolutionRate,
      changePercentThisMonth: '+12%',
      activityDays: [
        { day: 'Monday', count: 3, short: 'Mon' },
        { day: 'Tuesday', count: 5, short: 'Tue' },
        { day: 'Wednesday', count: 2, short: 'Wed' },
        { day: 'Thursday', count: 6, short: 'Thu' },
        { day: 'Friday', count: 4, short: 'Fri' },
        { day: 'Saturday', count: 3, short: 'Sat' },
        { day: 'Sunday', count: 1, short: 'Sun' },
      ],
      severityCounts: {
        Critical: 4,
        High: 8,
        Medium: 9,
        Low: 3,
      },
    };
  }

  public resetDemoData() {
    this.incidents = [...SEEDED_INCIDENTS];
    this.save();
  }
}

export const incidentService = new IncidentService();
