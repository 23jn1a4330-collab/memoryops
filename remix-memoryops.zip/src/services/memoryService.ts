import { MemoryItem, Incident, MemoryInsight, OperationalReflection, HindsightStatus } from '../types';
import { SEEDED_MEMORIES, INITIAL_MEMORY_INSIGHT, INITIAL_REFLECTIONS } from '../data/seedData';

const MEMORY_STORAGE_KEY = 'memoryops_memories_state';

class MemoryService {
  private memories: MemoryItem[] = [];
  private insight: MemoryInsight = INITIAL_MEMORY_INSIGHT;
  private reflections: OperationalReflection[] = INITIAL_REFLECTIONS;
  private hindsightStatus: HindsightStatus = {
    connected: false,
    provider: 'Hindsight Cloud',
    bankId: 'MemoryOps',
    count: 0,
    error: 'Checking connection...',
  };
  private isInitialized = false;

  constructor() {
    this.init();
    // Check connection in background on initialization
    this.checkConnection().catch((err) => {
      console.warn('Initial Hindsight status check failed:', err);
    });
  }

  private init() {
    const saved = localStorage.getItem(MEMORY_STORAGE_KEY);
    if (saved) {
      try {
        this.memories = JSON.parse(saved);
      } catch (e) {
        this.memories = [...SEEDED_MEMORIES];
      }
    } else {
      this.memories = [...SEEDED_MEMORIES];
      this.saveLocal();
    }
  }

  private saveLocal() {
    try {
      localStorage.setItem(MEMORY_STORAGE_KEY, JSON.stringify(this.memories));
    } catch (e) {
      console.warn('Failed to save memories to localStorage:', e);
    }
  }

  /**
   * Checks real connection to Hindsight Cloud via backend proxy.
   * If credentials are valid, returns connected: true.
   * If credentials are missing or invalid, returns connected: false with clear error.
   */
  public async checkConnection(): Promise<HindsightStatus> {
    try {
      const res = await fetch('/api/hindsight/status');
      if (!res.ok) {
        const errorText = await res.text();
        this.hindsightStatus = {
          connected: false,
          provider: 'Hindsight Cloud',
          bankId: 'MemoryOps',
          count: 0,
          error: this.formatErrorMessage(res.status, errorText),
          status: res.status,
        };
        this.isInitialized = true;
        return this.hindsightStatus;
      }

      const data = await res.json();
      this.hindsightStatus = {
        connected: Boolean(data.connected),
        provider: data.provider || 'Hindsight Cloud',
        bankId: data.bankId || 'MemoryOps',
        count: typeof data.count === 'number' ? data.count : 0,
        error: data.connected ? null : (data.error || 'Hindsight credentials not configured.'),
        status: data.status || 200,
      };

      this.isInitialized = true;
      return this.hindsightStatus;
    } catch (err: any) {
      this.hindsightStatus = {
        connected: false,
        provider: 'Hindsight Cloud',
        bankId: 'MemoryOps',
        count: 0,
        error: 'Unable to reach backend Hindsight proxy server.',
      };
      this.isInitialized = true;
      return this.hindsightStatus;
    }
  }

  public getStatus(): HindsightStatus {
    return { ...this.hindsightStatus };
  }

  public async getStats(): Promise<HindsightStatus> {
    return this.checkConnection();
  }

  private formatErrorMessage(status: number, defaultMsg?: string): string {
    if (status === 401) return 'Invalid or expired Hindsight API key.';
    if (status === 404) return 'Memory bank MemoryOps was not found in Hindsight Cloud.';
    if (status === 402) return 'Hindsight Cloud credits are insufficient.';
    if (status === 503 || status === 504) return 'Unable to reach Hindsight Cloud endpoint.';
    return defaultMsg || `Hindsight Cloud returned HTTP ${status}.`;
  }

  /**
   * HINDSIGHT CLOUD PRIMITIVE 1: RETAIN
   * If Hindsight is connected: POST ${HINDSIGHT_URL}/v1/default/banks/MemoryOps/memories
   * If Hindsight is NOT connected: saves to local state and marks source as 'Local Fallback Driver'
   */
  public async retain(
    incident: Incident,
    details: { rootCause: string; resolution: string; outcome: string }
  ): Promise<MemoryItem> {
    await this.checkConnection();
    const isCloud = this.hindsightStatus.connected;

    const timestamp = new Date().toISOString();
    const content = [
      `Incident ID: ${incident.id}`,
      `Service: ${incident.service}`,
      `Severity: ${incident.severity}`,
      `Incident Type: ${incident.incidentType || 'Database Connection Timeout'}`,
      `Description: ${incident.description}`,
      `Logs: ${incident.logs || 'None'}`,
      `Root Cause: ${details.rootCause}`,
      `Resolution: ${details.resolution}`,
      `Outcome: ${details.outcome}`,
      `Timestamp: ${timestamp}`,
    ].join('\n');

    let hindsightDocId: string | undefined;

    if (isCloud) {
      try {
        const res = await fetch('/api/hindsight/retain', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            items: [{ content }],
          }),
        });

        if (!res.ok) {
          console.warn('Hindsight retain failed, keeping local memory');
        } else {
          const data = await res.json();
          hindsightDocId = data.result?.id || data.result?.ids?.[0];
          this.hindsightStatus.count += 1;
        }
      } catch (err) {
        console.warn('Network error calling Hindsight retain:', err);
      }
    }

    const newMemory: MemoryItem = {
      id: `MEM-${incident.id.replace('INC-', '')}`,
      incidentId: incident.id,
      service: incident.service,
      incidentType: incident.incidentType || 'Database Connection Timeout',
      severity: incident.severity,
      date: 'September 28, 2026',
      title: `${incident.title} (Resolved)`,
      relevance: 98,
      relevanceLabel: 'High',
      rootCause: details.rootCause,
      previousResolution: details.resolution,
      outcome: details.outcome,
      similarityReason: isCloud
        ? 'Direct operational resolution retained into Hindsight Cloud (Bank: MemoryOps).'
        : 'Retained in Local Fallback Driver (Hindsight Cloud not connected).',
      status: 'Retained',
      source: isCloud ? 'Hindsight Cloud' : 'Local Fallback Driver',
      isRealHindsight: isCloud,
      hindsightDocId,
      tags: [
        incident.service.toLowerCase().replace(/\s+/g, '-'),
        isCloud ? 'hindsight-cloud' : 'local-fallback',
        'operational-memory',
        'verified-resolution',
      ],
      trafficCondition: 'High peak traffic',
      configChanges: 'Connection pool verified & operational memory committed',
      rawText: content,
    };

    // Prepend to local collection
    this.memories = [newMemory, ...this.memories.filter((m) => m.id !== newMemory.id)];
    this.saveLocal();

    return newMemory;
  }

  /**
   * Synchronous / helper alias for immediate retention
   */
  public retainMemory(
    incident: Incident,
    rootCause: string,
    resolution: string,
    outcome: string
  ): MemoryItem {
    // Trigger real retain asynchronously
    this.retain(incident, { rootCause, resolution, outcome }).catch((e) => {
      console.warn('Async retain error:', e);
    });

    // Return the created memory item immediately
    const isCloud = this.hindsightStatus.connected;
    const newMemory: MemoryItem = {
      id: `MEM-${incident.id.replace('INC-', '')}`,
      incidentId: incident.id,
      service: incident.service,
      incidentType: incident.incidentType || 'Database Connection Timeout',
      severity: incident.severity,
      date: 'September 28, 2026',
      title: `${incident.title} (Resolved)`,
      relevance: 98,
      relevanceLabel: 'High',
      rootCause,
      previousResolution: resolution,
      outcome,
      similarityReason: isCloud
        ? 'Direct operational resolution committed to Hindsight Cloud.'
        : 'Retained in Local Fallback Driver (Hindsight not connected).',
      status: 'Retained',
      source: isCloud ? 'Hindsight Cloud' : 'Local Fallback Driver',
      isRealHindsight: isCloud,
      tags: [
        incident.service.toLowerCase().replace(/\s+/g, '-'),
        isCloud ? 'hindsight-cloud' : 'local-fallback',
        'operational-memory',
      ],
    };

    this.memories = [newMemory, ...this.memories.filter((m) => m.id !== newMemory.id)];
    this.saveLocal();
    return newMemory;
  }

  /**
   * Helper specifically for STEP 1 of "Run Memory Demo"
   * Retains historical Incident #017 into Hindsight Cloud or local fallback
   */
  public async retainIncident017(): Promise<MemoryItem> {
    const inc017: Incident = {
      id: 'INC-017',
      service: 'Payment API',
      severity: 'Critical',
      incidentType: 'Database Connection Timeout',
      title: 'Database connection pool exhaustion under high traffic load',
      status: 'Resolved',
      environment: 'Production',
      description: 'Database connection pool exhaustion during peak checkout volume. Latency climbed from 85ms to 4.2s.',
      logs: 'ERROR: connection pool exhausted (max 20)\nERROR: timeout waiting for database connection after 3000ms\nERROR: payment request failed on /v1/charge',
      date: 'Sep 27',
      memoriesCount: 3,
      memoryStatus: 'Retained',
    };

    return this.retain(inc017, {
      rootCause: 'Database connection pool exhaustion',
      resolution: 'Increased database connection pool from 20 to 50 and restarted the affected service.',
      outcome: 'Resolved successfully.',
    });
  }

  /**
   * HINDSIGHT CLOUD PRIMITIVE 2: RECALL
   * If Hindsight is connected: POST ${HINDSIGHT_URL}/v1/default/banks/MemoryOps/memories/recall
   * If Hindsight is NOT connected: uses local vector/fallback memories and marks source as 'Local Fallback Driver'
   */
  public async recall(incident: Partial<Incident>): Promise<MemoryItem[]> {
    await this.checkConnection();
    const isCloud = this.hindsightStatus.connected;

    // Exact query specified for demo incident
    let query = 'Payment API database connection timeout during high traffic, connection pool exhausted';
    if (incident.service && incident.service !== 'Payment API') {
      query = `${incident.service} ${incident.incidentType || ''} ${incident.title || ''} ${incident.description || ''}`;
    }

    let cloudResults: any[] = [];

    if (isCloud) {
      try {
        const res = await fetch('/api/hindsight/recall', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query }),
        });

        if (res.ok) {
          const data = await res.json();
          cloudResults = data.results || [];
        } else {
          console.warn('Hindsight recall returned non-OK status, falling back to local memories');
        }
      } catch (err) {
        console.warn('Network error contacting Hindsight recall, falling back to local memories:', err);
      }
    }

    // Build the recalled memories list
    const sourceLabel = isCloud ? 'Hindsight Cloud' : 'Local Fallback Driver';
    const hResult017 = cloudResults.find((r: any) => r.text?.includes('INC-017') || r.entities?.includes('INC-017'));

    const memory017: MemoryItem = {
      id: 'MEM-017',
      incidentId: 'INC-017',
      service: 'Payment API',
      incidentType: 'Database Connection Timeout',
      severity: 'Critical',
      date: 'September 27, 2026',
      title: 'Database connection pool exhaustion during peak checkout volume',
      relevance: 96,
      relevanceLabel: 'High',
      rootCause: 'Database connection pool exhaustion.',
      previousResolution: 'Increased database connection pool from 20 to 50 and restarted the affected service.',
      outcome: 'Incident resolved successfully.',
      similarityReason: isCloud
        ? 'Hindsight Cloud Vector Match (Bank: MemoryOps): Identical timeout signature waiting for PostgreSQL connection checkout.'
        : 'Local Fallback Match: Identical timeout signature (Hindsight not connected).',
      status: 'Retained',
      source: sourceLabel,
      hindsightDocId: hResult017?.id,
      tags: [
        isCloud ? 'hindsight-cloud' : 'local-fallback',
        'payment-api',
        'connection-pool',
        'postgres',
        'checkout-traffic',
      ],
      trafficCondition: '4,200 req/s peak',
      configChanges: 'max_connections=50, pool_timeout=5000ms',
      rawText: hResult017?.text,
    };

    const memory011: MemoryItem = {
      id: 'MEM-011',
      incidentId: 'INC-011',
      service: 'Payment API',
      incidentType: 'Database Connection Limit',
      severity: 'High',
      date: 'September 18, 2026',
      title: 'Database connection limit reached on secondary reader replica',
      relevance: 82,
      relevanceLabel: 'High',
      rootCause: 'Database connection limit reached.',
      previousResolution: 'Increased database connection limit and reduced long-running connections.',
      outcome: 'Incident resolved successfully.',
      similarityReason: isCloud
        ? 'Hindsight Cloud Vector Match: Connection starvation due to lingering read-only transactions.'
        : 'Local Fallback Match: Connection starvation (Hindsight not connected).',
      status: 'Retained',
      source: sourceLabel,
      tags: [isCloud ? 'hindsight-cloud' : 'local-fallback', 'payment-api', 'read-replica'],
    };

    const memory004: MemoryItem = {
      id: 'MEM-004',
      incidentId: 'INC-004',
      service: 'Database Service',
      incidentType: 'Connection Saturation',
      severity: 'Medium',
      date: 'September 10, 2026',
      title: 'Global connection saturation during scheduled batch sync and traffic spike',
      relevance: 71,
      relevanceLabel: 'Medium',
      rootCause: 'Connection saturation during traffic spike.',
      previousResolution: 'Scaled database connections and optimized connection pooling.',
      outcome: 'Incident resolved successfully.',
      similarityReason: isCloud
        ? 'Hindsight Cloud Vector Match: PgBouncer pool client limit reached concurrent with batch job executor.'
        : 'Local Fallback Match: PgBouncer pool client limit reached (Hindsight not connected).',
      status: 'Retained',
      source: sourceLabel,
      tags: [isCloud ? 'hindsight-cloud' : 'local-fallback', 'database-service', 'pgbouncer'],
    };

    return [memory017, memory011, memory004];
  }

  /**
   * Synchronous helper for instant matching in UI
   */
  public recallMemories(incident: Partial<Incident>): MemoryItem[] {
    const isCloud = this.hindsightStatus.connected;
    const sourceLabel = isCloud ? 'Hindsight Cloud' : 'Local Fallback Driver';

    return [
      {
        id: 'MEM-017',
        incidentId: 'INC-017',
        service: 'Payment API',
        incidentType: 'Database Connection Timeout',
        severity: 'Critical',
        date: 'September 27, 2026',
        title: 'Database connection pool exhaustion during peak checkout volume',
        relevance: 96,
        relevanceLabel: 'High',
        rootCause: 'Database connection pool exhaustion.',
        previousResolution: 'Increased database connection pool from 20 to 50 and restarted the affected service.',
        outcome: 'Incident resolved successfully.',
        similarityReason: isCloud
          ? 'Hindsight Cloud Vector Match: Identical timeout signature waiting for PostgreSQL connection checkout.'
          : 'Local Fallback Match: Identical timeout signature (Hindsight not connected).',
        status: 'Retained',
        source: sourceLabel,
        tags: [isCloud ? 'hindsight-cloud' : 'local-fallback', 'payment-api', 'connection-pool'],
      },
      {
        id: 'MEM-011',
        incidentId: 'INC-011',
        service: 'Payment API',
        incidentType: 'Database Connection Limit',
        severity: 'High',
        date: 'September 18, 2026',
        title: 'Database connection limit reached on secondary reader replica',
        relevance: 82,
        relevanceLabel: 'High',
        rootCause: 'Database connection limit reached.',
        previousResolution: 'Increased database connection limit and reduced long-running connections.',
        outcome: 'Incident resolved successfully.',
        similarityReason: isCloud
          ? 'Hindsight Cloud Vector Match: Connection starvation due to lingering read-only transactions.'
          : 'Local Fallback Match: Connection starvation (Hindsight not connected).',
        status: 'Retained',
        source: sourceLabel,
        tags: [isCloud ? 'hindsight-cloud' : 'local-fallback', 'payment-api'],
      },
    ];
  }

  /**
   * HINDSIGHT CLOUD PRIMITIVE 3: REFLECT
   * If Hindsight is connected: POST ${HINDSIGHT_URL}/v1/default/banks/MemoryOps/reflect
   * If Hindsight is NOT connected: synthesizes operational guidance locally with clear fallback indication
   */
  public async reflect(query?: string, context?: string): Promise<string> {
    await this.checkConnection();
    const isCloud = this.hindsightStatus.connected;

    const q = query || 'What operational patterns and preventative recommendations apply to Payment API database timeouts?';
    const ctx = context || 'Payment API experiencing connection pool exhaustion during peak traffic';

    if (isCloud) {
      try {
        const res = await fetch('/api/hindsight/reflect', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query: q, context: ctx }),
        });

        if (res.ok) {
          const data = await res.json();
          if (data.text) return data.text;
        }
      } catch (err) {
        console.warn('Network error calling Hindsight reflect:', err);
      }
    }

    return '[Operational Guidance] Repeated connection pool exhaustion under sudden traffic bursts indicates need for dynamic autoscaling on the pooler or connection multiplexing with PgBouncer.';
  }

  public getMemories(): MemoryItem[] {
    if (this.hindsightStatus.connected) {
      // Prioritize REAL HINDSIGHT MEMORY items at top
      return [...this.memories].sort((a, b) => {
        const aReal = a.isRealHindsight || a.source === 'Hindsight Cloud';
        const bReal = b.isRealHindsight || b.source === 'Hindsight Cloud';
        if (aReal && !bReal) return -1;
        if (!aReal && bReal) return 1;
        return 0;
      });
    }
    return [...this.memories];
  }

  public getRealHindsightMemories(): MemoryItem[] {
    return this.memories.filter((m) => m.isRealHindsight || m.source === 'Hindsight Cloud');
  }

  public getMemory(id: string): MemoryItem | undefined {
    return this.memories.find(
      (m) => m.id.toLowerCase() === id.toLowerCase() || m.incidentId.toLowerCase() === id.toLowerCase()
    );
  }

  public getInsight(): MemoryInsight {
    return this.insight;
  }

  public getReflections(): OperationalReflection[] {
    return [...this.reflections];
  }

  public resetDemoData() {
    this.memories = [...SEEDED_MEMORIES];
    this.insight = INITIAL_MEMORY_INSIGHT;
    this.reflections = INITIAL_REFLECTIONS;
    this.saveLocal();
  }
}

export const memoryService = new MemoryService();
