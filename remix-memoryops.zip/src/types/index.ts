export type SeverityLevel = 'Low' | 'Medium' | 'High' | 'Critical';
export type IncidentStatus = 'Investigating' | 'Identified' | 'Mitigating' | 'Resolved';
export type Environment = 'Production' | 'Staging' | 'Development';
export type ServiceName = 
  | 'Payment API' 
  | 'Authentication Service' 
  | 'Database Service' 
  | 'Notification Service' 
  | 'Order Service';

export interface Incident {
  id: string;
  service: ServiceName;
  incidentType: string; // e.g. "Database Connection Timeout"
  title: string;
  severity: SeverityLevel;
  status: IncidentStatus;
  environment: Environment;
  description: string;
  logs: string;
  rootCause?: string;
  resolution?: string;
  outcome?: string;
  date: string;
  memoriesCount: number;
  memoryStatus: 'Retained' | 'Pending' | 'Not Retained';
  memoryId?: string;
  relatedIncidents?: string[];
  aiSummary?: string;
  timeline?: {
    time: string;
    event: string;
    actor: string;
  }[];
}

export interface MemoryItem {
  id: string;
  incidentId: string;
  service: ServiceName;
  incidentType: string;
  severity: SeverityLevel;
  date: string;
  title: string;
  relevance: number; // percentage, e.g. 96
  relevanceLabel: 'High' | 'Medium' | 'Low';
  rootCause: string;
  previousResolution: string;
  outcome: string;
  similarityReason: string;
  status: 'Retained';
  tags: string[];
  trafficCondition?: string;
  configChanges?: string;
  source?: 'Hindsight Cloud' | 'Local Demo Memory' | 'Local Fallback Driver' | 'Local Driver';
  isRealHindsight?: boolean;
  hindsightDocId?: string;
  rawText?: string;
}

export interface AIAnalysis {
  incidentId: string;
  mainStatement: string;
  likelyRootCause: string;
  historicalEvidence: string;
  recommendedActions: string[];
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  confidence: number; // e.g. 94
  withoutMemoryResponse: string;
  withMemoryResponse: string;
  memories: MemoryItem[];
  retrievedFromMemory: boolean;
  memorySource: string;
  reflectionGuidance?: string;
}

export interface IncidentFilters {
  search: string;
  service: string;
  severity: string;
  status: string;
}

export interface MemoryFilters {
  search: string;
  service: string;
  severity: string;
  incidentType: string;
}

export interface ToastMessage {
  id: string;
  title: string;
  message?: string;
  type: 'info' | 'success' | 'warning' | 'error';
  timestamp: number;
}

export interface MemoryInsight {
  title: string;
  service: ServiceName;
  summary: string;
  relatedIncidentsCount: number;
  successfulResolutionsCount: number;
  recurringPatternsCount: number;
}

export interface OperationalReflection {
  patternId: string;
  service: ServiceName;
  title: string;
  description: string;
  frequency: number;
  preventativeGuidance: string;
  retainedMemoriesCount: number;
  source?: string;
}

export interface HindsightStatus {
  connected: boolean;
  provider: string; // "Hindsight Cloud"
  bankId: string;   // "MemoryOps"
  count: number;
  error?: string | null;
  status?: number;
}
