import React, { useState, useEffect, useRef } from 'react';
import { Sidebar, PageId } from './components/Sidebar';
import { Header } from './components/Header';
import { ToastContainer } from './components/ToastContainer';
import { QuickSearchModal } from './components/modals/QuickSearchModal';
import { ResolveIncidentModal } from './components/modals/ResolveIncidentModal';
import { MemoryRetainedModal } from './components/modals/MemoryRetainedModal';
import { DemoTourController } from './components/DemoTourController';

import { DashboardPage } from './pages/DashboardPage';
import { IncidentsPage } from './pages/IncidentsPage';
import { NewIncidentPage } from './pages/NewIncidentPage';
import { AIAnalysisPage } from './pages/AIAnalysisPage';
import { MemoryExplorerPage } from './pages/MemoryExplorerPage';
import { IncidentDetailPage } from './pages/IncidentDetailPage';
import { SettingsPage } from './pages/SettingsPage';

import { incidentService } from './services/incidentService';
import { memoryService } from './services/memoryService';
import { aiService, AnalysisStepStatus } from './services/aiService';
import { Incident, MemoryItem, AIAnalysis, ToastMessage, ServiceName, SeverityLevel, Environment, HindsightStatus } from './types';

export default function App() {
  // Navigation & Page selection (Defaults directly to 'dashboard')
  const [currentPage, setCurrentPage] = useState<PageId>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Application Data State
  const [incidents, setIncidents] = useState<Incident[]>(() => incidentService.getIncidents());
  const [memories, setMemories] = useState<MemoryItem[]>(() => memoryService.getMemories());
  const [insight, setInsight] = useState(() => memoryService.getInsight());
  const [hindsightStatus, setHindsightStatus] = useState<HindsightStatus>(() => memoryService.getStatus());

  // Selected incident for detail view
  const [selectedIncident, setSelectedIncident] = useState<Incident>(() => incidents[0]);

  // AI Analysis State
  const [activeAnalysisIncident, setActiveAnalysisIncident] = useState<Incident>(() => incidents[0]);
  const [analysisResult, setAnalysisResult] = useState<AIAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisSteps, setAnalysisSteps] = useState<AnalysisStepStatus[]>([
    { step: 1, label: 'Reading current incident', state: 'pending' },
    { step: 2, label: 'Checking incident context', state: 'pending' },
    { step: 3, label: 'Searching historical memory', state: 'pending' },
    { step: 4, label: 'Comparing previous resolutions', state: 'pending' },
    { step: 5, label: 'Generating AI recommendation', state: 'pending' },
  ]);

  // Modals & Overlays
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isResolveModalOpen, setIsResolveModalOpen] = useState(false);
  const [isMemoryRetainedModalOpen, setIsMemoryRetainedModalOpen] = useState(false);
  const [lastResolutionData, setLastResolutionData] = useState({
    rootCause: 'Connection pool exhaustion',
    resolution: 'Increased database connection pool from 20 to 50 and restarted the payment service.',
    outcome: 'Resolved successfully.',
  });

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Demo Tour State (The 14-step automated experience)
  const [isDemoTourRunning, setIsDemoTourRunning] = useState(false);
  const [isDemoTourPaused, setIsDemoTourPaused] = useState(false);
  const [demoStepIndex, setDemoStepIndex] = useState(0);
  const demoTimerRef = useRef<NodeJS.Timeout | null>(null);

  const addToast = (
    title: string,
    message?: string,
    type: 'info' | 'success' | 'warning' | 'error' = 'info'
  ) => {
    const id = `${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { id, title, message, type, timestamp: Date.now() }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Keyboard shortcut for command palette
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Check Hindsight connection on app mount
  useEffect(() => {
    memoryService.checkConnection().then((status) => {
      setHindsightStatus(status);
    });
  }, []);

  // Sync initial analysis result if not set
  useEffect(() => {
    if (!analysisResult && incidents.length > 0) {
      const canonicalIncident = incidents.find((i) => i.id === 'INC-024') || incidents[0];
      const matched = memoryService.recallMemories(canonicalIncident);
      setAnalysisResult({
        incidentId: canonicalIncident.id,
        mainStatement:
          'This incident strongly resembles a previous Payment API database timeout caused by connection pool exhaustion.',
        likelyRootCause: 'Connection pool exhaustion under increased traffic.',
        historicalEvidence:
          'A similar incident occurred on September 27 and was successfully resolved by increasing the connection pool from 20 to 50.',
        recommendedActions: [
          'Check current connection pool utilization.',
          'Check active database connections.',
          'Verify the configured maximum pool size.',
          'Compare current traffic with the previous incident.',
          'Review recent database configuration changes.',
        ],
        riskLevel: 'HIGH',
        confidence: 96,
        retrievedFromMemory: true,
        memorySource: hindsightStatus.connected
          ? 'Hindsight Cloud Memory Bank: MemoryOps (Incident #017)'
          : 'Local Fallback Driver (Hindsight not connected)',
        withoutMemoryResponse:
          'Check your database configuration, network connectivity, credentials, connection pool settings, and database availability.',
        withMemoryResponse:
          'The current symptoms closely match Incident #017. The previous incident was caused by database connection pool exhaustion. Recommended action: increase the connection pool capacity, restart the affected service, and monitor connection utilization.',
        memories: matched,
      });
      setActiveAnalysisIncident(canonicalIncident);
    }
  }, [analysisResult, incidents, hindsightStatus.connected]);

  // Handle New Incident Creation & Analysis
  const handleAnalyzeNewIncident = async (data: {
    service: ServiceName;
    severity: SeverityLevel;
    title: string;
    description: string;
    logs: string;
    environment: Environment;
  }) => {
    // 1. Create incident in service
    const newInc = incidentService.createIncident(data);
    setIncidents(incidentService.getIncidents());
    setSelectedIncident(newInc);
    setActiveAnalysisIncident(newInc);

    addToast('Incident Created', `${newInc.id} logged for ${newInc.service}.`, 'info');

    // 2. Run analysis with step updates
    setIsAnalyzing(true);
    try {
      const result = await aiService.analyzeIncident(newInc, (steps) => {
        setAnalysisSteps(steps);
      });

      const updatedStatus = memoryService.getStatus();
      setHindsightStatus(updatedStatus);
      setAnalysisResult(result);

      if (updatedStatus.connected) {
        addToast('Hindsight Cloud Recall Active', '3 historical memories retrieved from Bank: MemoryOps.', 'success');
      } else {
        addToast('Recall Complete (Fallback)', '3 memories loaded from local vector fallback.', 'info');
      }
      addToast('Analysis Complete', 'Context-aware recommendation generated.', 'success');

      setTimeout(() => {
        setIsAnalyzing(false);
        setCurrentPage('ai-analysis');
      }, 500);
    } catch (err) {
      console.error(err);
      setIsAnalyzing(false);
      addToast('Analysis Failed', 'Could not complete memory recall. Please try again.', 'error');
    }
  };

  // Run AI Analysis for an existing incident
  const handleRunAnalysisForIncident = async (inc: Incident) => {
    setActiveAnalysisIncident(inc);
    setIsAnalyzing(true);
    setCurrentPage('new-incident');

    try {
      const result = await aiService.analyzeIncident(inc, (steps) => {
        setAnalysisSteps(steps);
      });
      setAnalysisResult(result);
      addToast('Analysis Complete', `Correlated with ${result.memories.length} historical memories.`, 'success');
      setTimeout(() => {
        setIsAnalyzing(false);
        setCurrentPage('ai-analysis');
      }, 500);
    } catch (e) {
      setIsAnalyzing(false);
      addToast('Analysis Error', 'Unable to synthesize recommendation.', 'error');
    }
  };

  // Handle Incident Resolution & Memory Retention
  const handleResolveAndRemember = async (data: {
    rootCause: string;
    resolution: string;
    outcome: string;
  }) => {
    const incId = activeAnalysisIncident.id;
    const resolved = incidentService.resolveIncident(
      incId,
      data.rootCause,
      data.resolution,
      data.outcome
    );

    if (resolved) {
      // Retain in REAL Hindsight Cloud API
      await memoryService.retain(resolved, data);

      // Refresh Hindsight stats & memory count
      const updatedStatus = await memoryService.checkConnection();
      setHindsightStatus(updatedStatus);

      // Refresh local states
      setIncidents(incidentService.getIncidents());
      setMemories(memoryService.getMemories());
      setInsight(memoryService.getInsight());
      setSelectedIncident(resolved);
      setActiveAnalysisIncident(resolved);

      setLastResolutionData(data);
      setIsResolveModalOpen(false);
      setIsMemoryRetainedModalOpen(true);

      addToast(
        'Memory learned successfully',
        'This incident has been retained in Hindsight and can improve future incident responses.',
        'success'
      );
    }
  };

  // Reset Demo Data
  const handleResetData = async () => {
    incidentService.resetDemoData();
    memoryService.resetDemoData();
    const updatedStatus = await memoryService.checkConnection();
    setHindsightStatus(updatedStatus);
    setIncidents(incidentService.getIncidents());
    setMemories(memoryService.getMemories());
    setInsight(memoryService.getInsight());
    setSelectedIncident(incidentService.getIncidents()[0]);
  };

  // 7-Stage Core Story Automated Demo Tour (Approx 35-45 seconds total)
  const DEMO_STEPS: { label: string; duration: number; action: () => void | Promise<void> }[] = [
    {
      label: 'Phase 1/7: OLD INCIDENT — Retain & inspect historical Incident #017 in operational memory',
      duration: 4500,
      action: async () => {
        setCurrentPage('memory-explorer');
        try {
          await memoryService.retainIncident017();
          const updatedStatus = await memoryService.checkConnection();
          setHindsightStatus(updatedStatus);
          setMemories(memoryService.getMemories());
        } catch (e) {
          console.warn('Error retaining incident 017 in demo:', e);
        }
        addToast('Historical Baseline', 'Incident #017: Historical database pool exhaustion retained in Hindsight Cloud.', 'info');
      },
    },
    {
      label: 'Phase 2/7: NEW INCIDENT — New production outage detected on Payment API',
      duration: 4500,
      action: () => {
        setCurrentPage('new-incident');
        addToast('New Outage Detected', 'Payment requests failing intermittently during high peak traffic.', 'warning');
      },
    },
    {
      label: 'Phase 3/7: MEMORY RETRIEVAL — Querying Hindsight operational vector memory',
      duration: 4500,
      action: async () => {
        setIsAnalyzing(true);
        setAnalysisSteps([
          { step: 1, label: 'Analyzing incident...', state: 'completed', detail: 'Symptoms identified' },
          { step: 2, label: 'Searching historical memory in Hindsight Cloud...', state: 'active', detail: 'Vector recall active' },
          { step: 3, label: 'Relevant memories found...', state: 'pending' },
          { step: 4, label: 'Generating recommendation...', state: 'pending' },
        ]);
        try {
          const analysis = await aiService.analyzeIncident(activeAnalysisIncident);
          setAnalysisResult(analysis);
        } catch (e) {
          console.warn('Analysis in demo error:', e);
        }
      },
    },
    {
      label: 'Phase 4/7: MATCH FOUND — Incident #017 retrieved from Hindsight with High relevance (96%)',
      duration: 4500,
      action: () => {
        setAnalysisSteps([
          { step: 1, label: 'Analyzing incident...', state: 'completed' },
          { step: 2, label: 'Searching historical memory in Hindsight Cloud...', state: 'completed' },
          { step: 3, label: 'Relevant memories found...', state: 'completed', detail: 'Hindsight Memory Found: Incident #017' },
          { step: 4, label: 'Generating recommendation...', state: 'active' },
        ]);
        addToast('Hindsight Memory Found', 'Incident #017 retrieved from Hindsight Cloud (Bank: MemoryOps).', 'success');
      },
    },
    {
      label: 'Phase 5/7: AI RECOMMENDATION — Context-aware recommendation derived from retrieved memory',
      duration: 6000,
      action: () => {
        setIsAnalyzing(false);
        setCurrentPage('ai-analysis');
        window.scrollTo({ top: 300, behavior: 'smooth' });
        addToast('AI Recommendation', 'Recommended: increase pool from 20 to 50 sockets based on Incident #017.', 'info');
      },
    },
    {
      label: 'Phase 6/7: RESOLUTION — Executing "Resolve & Remember"',
      duration: 4500,
      action: () => {
        setIsResolveModalOpen(true);
        setTimeout(async () => {
          await handleResolveAndRemember({
            rootCause: 'Database connection pool exhaustion.',
            resolution: 'Increased database connection pool from 20 to 50 and restarted the affected service.',
            outcome: 'Incident resolved successfully.',
          });
        }, 1200);
      },
    },
    {
      label: 'Phase 7/7: MEMORY RETAINED — New operational experience committed to Hindsight',
      duration: 5500,
      action: async () => {
        setIsMemoryRetainedModalOpen(false);
        const updatedStatus = await memoryService.checkConnection();
        setHindsightStatus(updatedStatus);
        setMemories(memoryService.getMemories());
        setCurrentPage('memory-explorer');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        addToast(
          'Memory learned successfully',
          'This incident has been retained in Hindsight and can improve future incident responses.',
          'success'
        );
      },
    },
  ];

  // Start demo tour
  const handleStartDemoTour = () => {
    setIsDemoTourRunning(true);
    setIsDemoTourPaused(false);
    setDemoStepIndex(0);
    DEMO_STEPS[0].action();
  };

  // Demo step timer runner
  useEffect(() => {
    if (!isDemoTourRunning || isDemoTourPaused) {
      if (demoTimerRef.current) clearTimeout(demoTimerRef.current);
      return;
    }

    const currentStep = DEMO_STEPS[demoStepIndex];
    demoTimerRef.current = setTimeout(() => {
      if (demoStepIndex < DEMO_STEPS.length - 1) {
        const nextIndex = demoStepIndex + 1;
        setDemoStepIndex(nextIndex);
        DEMO_STEPS[nextIndex].action();
      } else {
        // Finished
        setIsDemoTourRunning(false);
      }
    }, currentStep.duration);

    return () => {
      if (demoTimerRef.current) clearTimeout(demoTimerRef.current);
    };
  }, [isDemoTourRunning, isDemoTourPaused, demoStepIndex]);

  const handleNextDemoStep = () => {
    if (demoStepIndex < DEMO_STEPS.length - 1) {
      const nextIndex = demoStepIndex + 1;
      setDemoStepIndex(nextIndex);
      DEMO_STEPS[nextIndex].action();
    } else {
      setIsDemoTourRunning(false);
    }
  };

  const handleExitDemoTour = () => {
    setIsDemoTourRunning(false);
    setIsAnalyzing(false);
    setIsResolveModalOpen(false);
    setIsMemoryRetainedModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#0B1020] text-slate-100 flex flex-col font-sans">
      {/* Toast notifications */}
      <ToastContainer toasts={toasts} onDismiss={removeToast} />

      {/* Quick Search ⌘K Command Palette Modal */}
      <QuickSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        incidents={incidents}
        memories={memories}
        onSelectIncident={(inc) => {
          setSelectedIncident(inc);
          setCurrentPage('incident-detail');
        }}
        onSelectMemory={(mem) => {
          setCurrentPage('memory-explorer');
        }}
        onNavigate={(page) => setCurrentPage(page)}
      />

      {/* Resolve Incident Modal */}
      <ResolveIncidentModal
        isOpen={isResolveModalOpen}
        incident={activeAnalysisIncident}
        onClose={() => setIsResolveModalOpen(false)}
        onResolveAndRemember={handleResolveAndRemember}
      />

      {/* Memory Retained Success Modal */}
      <MemoryRetainedModal
        isOpen={isMemoryRetainedModalOpen}
        incident={activeAnalysisIncident}
        rootCause={lastResolutionData.rootCause}
        resolution={lastResolutionData.resolution}
        outcome={lastResolutionData.outcome}
        onClose={() => setIsMemoryRetainedModalOpen(false)}
        onViewMemory={() => {
          setIsMemoryRetainedModalOpen(false);
          setCurrentPage('memory-explorer');
        }}
      />

      {/* Demo Tour Floating Controller */}
      <DemoTourController
        isRunning={isDemoTourRunning}
        isPaused={isDemoTourPaused}
        currentStepIndex={demoStepIndex}
        totalSteps={DEMO_STEPS.length}
        currentStepLabel={DEMO_STEPS[demoStepIndex]?.label || ''}
        onPauseToggle={() => setIsDemoTourPaused((prev) => !prev)}
        onNextStep={handleNextDemoStep}
        onExit={handleExitDemoTour}
      />

      {/* Main Responsive Layout */}
      <div className="flex flex-1">
        {/* Left Sidebar */}
        <Sidebar
          currentPage={currentPage}
          onNavigate={(page) => setCurrentPage(page)}
          isOpenMobile={isMobileMenuOpen}
          onCloseMobile={() => setIsMobileMenuOpen(false)}
          hindsightStatus={hindsightStatus}
        />

        {/* Content Area */}
        <div className="flex-1 flex flex-col min-w-0 lg:pl-64">
          {/* Top Header */}
          <Header
            onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
            onOpenSearch={() => setIsSearchOpen(true)}
            hindsightStatus={hindsightStatus}
          />

          {/* Main Viewport Content */}
          <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
            {currentPage === 'dashboard' && (
              <DashboardPage
                incidents={incidents}
                insight={insight}
                memoriesCount={hindsightStatus?.connected ? (hindsightStatus.count ?? 0) : memories.length}
                onNavigate={(page) => setCurrentPage(page)}
                onSelectIncident={(inc) => {
                  setSelectedIncident(inc);
                  setCurrentPage('incident-detail');
                }}
                onStartDemoTour={handleStartDemoTour}
                hindsightStatus={hindsightStatus}
              />
            )}

            {currentPage === 'incidents' && (
              <IncidentsPage
                incidents={incidents}
                onNavigate={(page) => setCurrentPage(page)}
                onSelectIncident={(inc) => {
                  setSelectedIncident(inc);
                  setCurrentPage('incident-detail');
                }}
              />
            )}

            {currentPage === 'new-incident' && (
              <NewIncidentPage
                onAnalyze={handleAnalyzeNewIncident}
                isAnalyzing={isAnalyzing}
                analysisSteps={analysisSteps}
              />
            )}

            {currentPage === 'ai-analysis' && analysisResult && (
              <AIAnalysisPage
                currentIncident={activeAnalysisIncident}
                analysis={analysisResult}
                onResolveClick={() => setIsResolveModalOpen(true)}
                onViewIncidentDetail={(incId) => {
                  const target = incidents.find((i) => i.id === incId);
                  if (target) {
                    setSelectedIncident(target);
                    setCurrentPage('incident-detail');
                  }
                }}
                onNavigate={(page) => setCurrentPage(page)}
                hindsightStatus={hindsightStatus}
              />
            )}

            {currentPage === 'memory-explorer' && (
              <MemoryExplorerPage
                memories={memories}
                onViewIncident={(incId) => {
                  const target = incidents.find((i) => i.id === incId);
                  if (target) {
                    setSelectedIncident(target);
                    setCurrentPage('incident-detail');
                  }
                }}
                onNavigate={(page) => setCurrentPage(page)}
                hindsightStatus={hindsightStatus}
              />
            )}

            {currentPage === 'incident-detail' && selectedIncident && (
              <IncidentDetailPage
                incident={selectedIncident}
                onBack={() => setCurrentPage('incidents')}
                onRunAnalysis={handleRunAnalysisForIncident}
                onNavigate={(page) => setCurrentPage(page)}
              />
            )}

            {currentPage === 'settings' && (
              <SettingsPage
                onResetData={handleResetData}
                onShowToast={addToast}
                hindsightStatus={hindsightStatus}
              />
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
