import React from 'react';
import { 
  Sparkles, 
  BrainCircuit, 
  CheckCircle2, 
  ExternalLink, 
  Check, 
  ShieldAlert, 
  Zap, 
  ArrowDown,
  Database,
  ArrowRight,
  AlertTriangle
} from 'lucide-react';
import { Incident, AIAnalysis, HindsightStatus } from '../types';
import { PageId } from '../components/Sidebar';
import { MemoryLearningIndicator } from '../components/MemoryLearningIndicator';

interface AIAnalysisPageProps {
  currentIncident: Incident;
  analysis: AIAnalysis;
  onResolveClick: () => void;
  onViewIncidentDetail: (incidentId: string) => void;
  onNavigate: (page: PageId) => void;
  hindsightStatus?: HindsightStatus;
}

export const AIAnalysisPage: React.FC<AIAnalysisPageProps> = ({
  currentIncident,
  analysis,
  onResolveClick,
  onViewIncidentDetail,
  onNavigate,
  hindsightStatus,
}) => {
  const memories = analysis.memories || [];
  const memory1 = memories[0] || {
    id: 'MEM-017',
    incidentId: 'INC-017',
    service: 'Payment API',
    incidentType: 'Database Connection Timeout',
    severity: 'Critical',
    date: 'September 27, 2026',
    relevance: 96,
    relevanceLabel: 'High',
    rootCause: 'Database connection pool exhaustion.',
    previousResolution: 'Increased database connection pool from 20 to 50 and restarted the affected service.',
    outcome: 'Incident resolved successfully.',
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider mb-1">
            {hindsightStatus?.connected ? (
              <span className="text-purple-400 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" />
                Hindsight Cloud Intelligence (Bank: MemoryOps)
              </span>
            ) : (
              <span className="text-amber-400 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4" />
                Local Fallback Intelligence (Hindsight Not Connected)
              </span>
            )}
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">AI Incident Analysis</h1>
          <p className="text-sm text-slate-400 mt-1">
            Context-aware analysis powered by {hindsightStatus?.connected ? 'Hindsight Cloud operational memory' : 'historical operational memory (local fallback)'}.
          </p>
        </div>

        {currentIncident.status === 'Resolved' ? (
          <div className="flex items-center gap-2 self-start sm:self-auto">
            <span className="px-3.5 py-2 text-xs font-semibold text-emerald-300 bg-emerald-950/60 border border-emerald-500/50 rounded-lg flex items-center gap-2 shadow-sm">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Resolved & Retained</span>
            </span>
            <button
              onClick={() => onNavigate('memory-explorer')}
              className="px-3.5 py-2 text-xs font-semibold text-purple-300 bg-purple-950/40 hover:bg-purple-900/60 border border-purple-700/60 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <BrainCircuit className="w-4 h-4 text-purple-400" />
              <span>View Memory</span>
            </button>
          </div>
        ) : (
          <button
            onClick={onResolveClick}
            className="px-5 py-2.5 text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 rounded-lg shadow-lg shadow-emerald-950/40 flex items-center gap-2 self-start sm:self-auto transition-transform active:scale-98 cursor-pointer"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Resolve & Remember</span>
          </button>
        )}
      </div>

      {/* Prominent banner if Hindsight is not connected */}
      {!hindsightStatus?.connected && (
        <div className="p-3.5 bg-amber-950/25 border border-amber-800/50 rounded-xl flex items-center justify-between gap-3 text-xs text-amber-200">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              <strong>Hindsight Not Connected:</strong> Recommendation generated with local vector fallback. Real Hindsight Cloud requires <code className="bg-amber-950/70 px-1 py-0.5 rounded font-mono text-amber-300">HINDSIGHT_API_KEY</code>.
            </span>
          </div>
          <button
            onClick={() => onNavigate('settings')}
            className="text-[11px] font-medium text-amber-300 hover:text-white underline shrink-0 cursor-pointer"
          >
            Configure →
          </button>
        </div>
      )}

      {/* Memory Learning Indicator: 6-Stage Visual Sequence */}
      <MemoryLearningIndicator
        currentIncident={currentIncident}
        hindsightStatus={hindsightStatus}
        recalledMemory={memory1}
        isResolved={currentIncident.status === 'Resolved'}
        isRetained={currentIncident.memoryStatus === 'Retained' || currentIncident.status === 'Resolved'}
      />

      {/* SECTION 1: CURRENT INCIDENT */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">CURRENT INCIDENT</span>
            <span className="font-mono text-xs font-semibold text-purple-400 bg-purple-950/40 px-2.5 py-0.5 rounded border border-purple-800/40">
              {currentIncident.id || 'INC-025'}
            </span>
          </div>
          <span className="text-xs font-medium text-slate-400">{currentIncident.environment}</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs mb-4">
          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-[10px] uppercase font-semibold text-slate-500 block mb-1">Service</span>
            <span className="text-sm font-bold text-white">{currentIncident.service}</span>
          </div>
          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-[10px] uppercase font-semibold text-slate-500 block mb-1">Severity</span>
            <span className="text-sm font-bold text-red-400 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
              {currentIncident.severity}
            </span>
          </div>
          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-[10px] uppercase font-semibold text-slate-500 block mb-1">Incident Type</span>
            <span className="text-sm font-bold text-slate-200">
              {currentIncident.incidentType || 'Database Connection Timeout'}
            </span>
          </div>
        </div>

        <div className="space-y-2">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">Description:</span>
          <p className="text-sm text-slate-300 bg-slate-900/60 p-3.5 rounded-lg border border-slate-800/80 leading-relaxed">
            {currentIncident.description}
          </p>
        </div>

        {currentIncident.logs && (
          <div className="mt-4">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block mb-1.5">Captured Logs:</span>
            <pre className="p-3.5 bg-slate-950 rounded-lg border border-slate-800 text-xs font-mono text-purple-300 whitespace-pre-wrap leading-relaxed">
              {currentIncident.logs}
            </pre>
          </div>
        )}
      </div>

      {/* SECTION 2: HISTORICAL MEMORY */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BrainCircuit className="w-5 h-5 text-purple-400" />
            <h2 className="text-lg font-bold text-white tracking-tight">HISTORICAL MEMORY</h2>
          </div>
          {hindsightStatus?.connected ? (
            <span className="text-xs font-mono text-purple-300 bg-purple-950/50 px-3 py-1 rounded-full border border-purple-800/50 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
              Matched via Hindsight Cloud (Bank: MemoryOps)
            </span>
          ) : (
            <span className="text-xs font-mono text-amber-300 bg-amber-950/50 px-3 py-1 rounded-full border border-amber-800/50 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              Local Fallback Match (Hindsight Offline)
            </span>
          )}
        </div>

        {/* Primary Emphasized Memory Card: Incident #017 */}
        <div className="bg-gradient-to-b from-purple-950/30 to-[#111827] border-2 border-purple-500 rounded-xl p-6 shadow-xl shadow-purple-950/40 relative">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-purple-800/40 mb-4">
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <span className="text-base font-bold text-white">Incident #017</span>
                <span className="text-slate-400 font-semibold">·</span>
                <span className="text-sm font-semibold text-purple-300">Payment API</span>
                <span className="text-slate-400 font-semibold">·</span>
                <span className="text-xs font-bold text-red-400">Critical</span>
                <span className="text-slate-400 font-semibold">·</span>
                <span className="text-xs font-medium text-purple-200">Database Connection Timeout</span>
              </div>
              <div className="flex flex-wrap items-center gap-2 mt-1">
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-purple-500/20 border border-purple-500/50 text-purple-300 font-mono text-[10px] font-bold">
                  <Sparkles className="w-3 h-3 text-purple-400" />
                  Hindsight Memory Found
                </span>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-purple-950/60 border border-purple-800 text-purple-300 font-mono text-[10px] font-semibold">
                  REAL HINDSIGHT MEMORY
                </span>
                <span className="text-xs text-slate-400">· {memory1.date}</span>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <span className="px-3 py-1 rounded-md bg-emerald-950/60 border border-emerald-800 text-xs font-bold text-emerald-400 font-mono">
                Memory relevance: High ({memory1.relevance}%)
              </span>
              <button
                onClick={() => onViewIncidentDetail(memory1.incidentId)}
                className="px-3 py-1 text-xs font-medium text-purple-300 hover:text-white bg-purple-900/40 hover:bg-purple-800/50 border border-purple-700/60 rounded-md flex items-center gap-1 transition-colors cursor-pointer"
              >
                <span>View Incident</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="p-3.5 rounded-lg bg-slate-900/90 border border-slate-800">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-amber-400 block mb-1">
                Root Cause:
              </span>
              <p className="text-sm font-medium text-slate-200">{memory1.rootCause}</p>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-900/90 border border-slate-800 md:col-span-1">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-purple-300 block mb-1">
                Resolution:
              </span>
              <p className="text-xs text-slate-300 leading-relaxed">{memory1.previousResolution}</p>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-900/90 border border-slate-800">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-emerald-400 block mb-1">
                Outcome:
              </span>
              <p className="text-sm font-semibold text-emerald-400 flex items-center gap-1.5 mt-0.5">
                <Check className="w-4 h-4" />
                {memory1.outcome}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 3: AI RECOMMENDATION */}
      <div className="bg-gradient-to-r from-purple-950/50 via-[#111827] to-slate-900 border-2 border-purple-500/80 rounded-2xl p-6 sm:p-7 shadow-2xl shadow-purple-950/50 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-purple-900/40">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-purple-600/30 text-purple-300 border border-purple-500/40 shadow-xs">
              <BrainCircuit className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white tracking-tight">AI RECOMMENDATION</h3>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[11px] font-semibold border border-purple-500/40">
                  <Sparkles className="w-3 h-3 text-purple-400" />
                  Grounded in Retrieved Operational Memory (Incident #017)
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-3 py-1 rounded-lg bg-red-950/50 border border-red-800 text-xs font-semibold text-red-300 flex items-center gap-1.5">
              <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
              <span>Risk: HIGH</span>
            </div>
            <div className="px-3 py-1 rounded-lg bg-purple-950/50 border border-purple-800 text-xs font-semibold text-purple-300 font-mono flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-purple-400" />
              <span>Confidence: 96%</span>
            </div>
          </div>
        </div>

        {/* Primary AI Recommendation Statement */}
        <div className="p-5 rounded-xl bg-purple-900/25 border border-purple-600/50 shadow-inner">
          <p className="text-base sm:text-lg font-medium text-purple-100 leading-relaxed font-sans">
            "{analysis.mainStatement}"
          </p>
        </div>

        {/* Recommended Actions Breakdown */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5">
          <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-300 mb-3 flex items-center gap-2">
            <span>Actionable Operational Steps</span>
            <span className="text-[11px] text-slate-400 font-normal">Based on previous verified resolution</span>
          </h4>
          <ol className="space-y-2.5 text-sm">
            {analysis.recommendedActions.map((action, idx) => (
              <li key={idx} className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-purple-600/30 text-purple-300 font-mono text-xs flex items-center justify-center shrink-0 border border-purple-500/40 mt-0.5">
                  {idx + 1}
                </span>
                <span className="text-slate-200">{action}</span>
              </li>
            ))}
          </ol>
        </div>
      </div>

      {/* SECTION 4: MEMORY FLOW VISUALIZATION */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-5">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">
              MEMORY FLOW VISUALIZATION
            </span>
            <span className="text-[10px] font-semibold text-purple-400 bg-purple-950/40 px-2 py-0.5 rounded border border-purple-800/40">
              6-Stage Pipeline
            </span>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {currentIncident.status === 'Resolved' ? 'Cycle: Complete & Retained' : 'Cycle: Pending Resolution'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* Node 1 */}
          <div className="bg-slate-900 border border-blue-500/50 rounded-xl p-3.5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] font-mono text-slate-400 uppercase">Stage 1</span>
                <span className="text-[10px] font-bold text-blue-300 bg-blue-950/70 border border-blue-600/50 px-1.5 py-0.5 rounded uppercase">
                  Applied
                </span>
              </div>
              <div className="text-xs font-bold text-white">1. INCIDENT RECEIVED</div>
              <div className="text-[11px] text-slate-400 mt-1 truncate">{currentIncident.service}</div>
            </div>
            <div className="text-[10px] font-mono text-slate-500 mt-2">{currentIncident.id || 'INC-025'}</div>
          </div>

          {/* Node 2 */}
          <div className="bg-purple-950/20 border border-purple-500/60 rounded-xl p-3.5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] font-mono text-purple-400 uppercase">Stage 2</span>
                <span className="text-[10px] font-bold text-purple-300 bg-purple-950/70 border border-purple-500/60 px-1.5 py-0.5 rounded uppercase">
                  Found
                </span>
              </div>
              <div className="text-xs font-bold text-purple-200">2. HINDSIGHT RECALL</div>
              <div className="text-[11px] text-slate-400 mt-1">Bank: MemoryOps</div>
            </div>
            <div className="text-[10px] font-mono text-purple-400 mt-2">Vector Search</div>
          </div>

          {/* Node 3 */}
          <div className="bg-purple-950/40 border border-purple-500/80 rounded-xl p-3.5 shadow-sm shadow-purple-950/40 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] font-mono text-purple-300 uppercase">Stage 3</span>
                <span className="text-[10px] font-bold text-purple-300 bg-purple-950/70 border border-purple-500/60 px-1.5 py-0.5 rounded uppercase">
                  Found
                </span>
              </div>
              <div className="text-xs font-bold text-white">3. HISTORICAL MEMORY FOUND</div>
              <div className="text-[11px] text-emerald-400 font-mono mt-1">Incident #017 (96%)</div>
            </div>
            <div className="text-[10px] font-mono text-purple-300 mt-2">Historical Pool Fix</div>
          </div>

          {/* Node 4 */}
          <div className="bg-slate-900 border border-blue-500/50 rounded-xl p-3.5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] font-mono text-slate-400 uppercase">Stage 4</span>
                <span className="text-[10px] font-bold text-blue-300 bg-blue-950/70 border border-blue-500/60 px-1.5 py-0.5 rounded uppercase">
                  Applied
                </span>
              </div>
              <div className="text-xs font-bold text-white">4. AI USES MEMORY</div>
              <div className="text-[11px] text-slate-400 mt-1">Grounded Recommendation</div>
            </div>
            <div className="text-[10px] font-mono text-blue-300 mt-2">Scale pool: 20 → 50</div>
          </div>

          {/* Node 5 */}
          <div className={`p-3.5 rounded-xl border flex flex-col justify-between ${
            currentIncident.status === 'Resolved'
              ? 'bg-emerald-950/30 border-emerald-500/80'
              : 'bg-slate-900/60 border-slate-800'
          }`}>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] font-mono text-slate-400 uppercase">Stage 5</span>
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase ${
                  currentIncident.status === 'Resolved'
                    ? 'text-emerald-300 bg-emerald-950/80 border border-emerald-500/60'
                    : 'text-slate-400 bg-slate-800 border border-slate-700'
                }`}>
                  {currentIncident.status === 'Resolved' ? 'Resolved' : 'Pending'}
                </span>
              </div>
              <div className={`text-xs font-bold ${currentIncident.status === 'Resolved' ? 'text-emerald-200' : 'text-slate-300'}`}>
                5. INCIDENT RESOLVED
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                {currentIncident.status === 'Resolved' ? 'Verified fix applied' : 'Resolve & Remember'}
              </div>
            </div>
            <div className="text-[10px] font-mono text-slate-500 mt-2">
              {currentIncident.status === 'Resolved' ? 'Service Healthy' : 'Action Required'}
            </div>
          </div>

          {/* Node 6 */}
          <div className={`p-3.5 rounded-xl border flex flex-col justify-between ${
            currentIncident.status === 'Resolved'
              ? 'bg-gradient-to-b from-emerald-950/40 to-purple-950/40 border-emerald-400/80 shadow-md shadow-emerald-950/40'
              : 'bg-slate-900/60 border-slate-800'
          }`}>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] font-mono text-purple-400 uppercase">Stage 6</span>
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase ${
                  currentIncident.status === 'Resolved'
                    ? 'text-emerald-200 bg-emerald-950/80 border border-emerald-400'
                    : 'text-slate-400 bg-slate-800 border border-slate-700'
                }`}>
                  {currentIncident.status === 'Resolved' ? 'Retained' : 'Pending'}
                </span>
              </div>
              <div className={`text-xs font-bold ${currentIncident.status === 'Resolved' ? 'text-white' : 'text-slate-400'}`}>
                6. NEW MEMORY RETAINED
              </div>
              <div className="text-[11px] text-purple-200 mt-1">
                {currentIncident.status === 'Resolved' ? 'Stored in Hindsight Cloud' : 'Commit on resolution'}
              </div>
            </div>
            <div className="text-[10px] font-mono text-purple-400 mt-2">
              {currentIncident.status === 'Resolved' ? 'Agent Learned' : 'Continuous Loop'}
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 5: BEFORE vs AFTER MEMORY */}
      <div className="space-y-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">BEFORE vs AFTER MEMORY</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Every resolved incident becomes future operational knowledge.
          </p>
        </div>

        {/* State Evolution Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* BEFORE State Card */}
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-bold text-slate-300">BEFORE Incident Resolution</h3>
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider bg-slate-800 px-2.5 py-0.5 rounded border border-slate-700">
                  Initial Knowledge State
                </span>
              </div>

              <div className="space-y-3 text-xs text-slate-300">
                <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-500 block mb-1">
                    Retained Knowledge:
                  </span>
                  <p className="text-slate-300">
                    The agent has historical knowledge from <strong className="text-white">Incident #017</strong> (Sep 27 connection pool fix).
                  </p>
                </div>

                <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-500 block mb-1">
                    Without Memory (Generic LLM fallback):
                  </span>
                  <p className="text-slate-400 italic">
                    "{analysis.withoutMemoryResponse}"
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400">
              Single historical data point · Generic troubleshooting requires multiple trial steps
            </div>
          </div>

          {/* AFTER State Card */}
          <div className="bg-gradient-to-b from-purple-950/40 to-[#111827] border-2 border-purple-500 rounded-xl p-6 shadow-xl shadow-purple-950/40 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-bold text-white">AFTER Incident Resolution</h3>
                <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider bg-emerald-950/60 px-2.5 py-0.5 rounded border border-emerald-800/40">
                  Expanded Operational Learning
                </span>
              </div>

              <div className="space-y-3 text-xs text-slate-200">
                <div className="p-3 rounded-lg bg-purple-950/30 border border-purple-700/40">
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-purple-300 block mb-1">
                    The agent now retains:
                  </span>
                  <ul className="space-y-1 text-slate-200">
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                      <span>Historical Incident #017 context & baseline</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                      <span>Current incident resolution & verified fix (pool 20 → 50)</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      <strong className="text-white">New operational learning & recurring traffic pattern</strong>
                    </li>
                  </ul>
                </div>

                <div className="p-3 rounded-lg bg-purple-950/30 border border-purple-700/40">
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-emerald-400 block mb-1">
                    With Memory (Hindsight Powered):
                  </span>
                  <p className="text-purple-100 font-medium">
                    "{analysis.withMemoryResponse}"
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-purple-800/40 text-[11px] text-purple-300 font-semibold flex items-center justify-between">
              <span>"Every resolved incident becomes future knowledge."</span>
              <span className="text-emerald-400 font-mono">Continuous SRE Loop</span>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 6: RESOLVE & REMEMBER ACTION BUTTON OR LEARNED SUCCESS STATE */}
      {currentIncident.status === 'Resolved' ? (
        <div className="p-6 rounded-2xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-purple-950/50 border-2 border-emerald-500/80 shadow-2xl shadow-emerald-950/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="p-3 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shrink-0">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white tracking-tight">Memory learned successfully</h3>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[10px] font-mono font-bold uppercase tracking-wider">
                  Bank: {hindsightStatus?.bankId || 'MemoryOps'}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-emerald-200/90 mt-1 font-medium">
                This incident has been retained in Hindsight and can improve future incident responses.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => onNavigate('memory-explorer')}
              className="px-5 py-2.5 text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-purple-600 to-emerald-600 hover:from-purple-500 hover:to-emerald-500 rounded-lg shadow-lg shadow-purple-950/50 flex items-center gap-2 transition-all transform hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
            >
              <BrainCircuit className="w-4 h-4" />
              <span>View in Memory Explorer</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="p-6 rounded-2xl bg-gradient-to-r from-purple-900/30 via-slate-900 to-emerald-950/30 border border-purple-700/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-white tracking-tight">Ready to resolve and commit this experience?</h3>
            <p className="text-xs text-slate-300 mt-1">
              Clicking "Resolve & Remember" updates the incident status, stores the verified resolution in Hindsight, and enriches future recommendations.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => onNavigate('incidents')}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>

            <button
              onClick={onResolveClick}
              className="px-6 py-2.5 text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 rounded-lg shadow-lg shadow-emerald-950/50 flex items-center gap-2 transition-all transform hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Resolve & Remember</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
