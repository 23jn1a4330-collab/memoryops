import React from 'react';
import { 
  ArrowLeft, 
  BrainCircuit, 
  CheckCircle2, 
  Clock, 
  Terminal, 
  Sparkles, 
  Database,
  ExternalLink,
  ShieldAlert,
  GitCommit,
  Check
} from 'lucide-react';
import { Incident } from '../types';
import { PageId } from '../components/Sidebar';

interface IncidentDetailPageProps {
  incident: Incident;
  onBack: () => void;
  onRunAnalysis: (incident: Incident) => void;
  onNavigate: (page: PageId) => void;
  onViewRelatedMemory?: (memoryId: string) => void;
}

export const IncidentDetailPage: React.FC<IncidentDetailPageProps> = ({
  incident,
  onBack,
  onRunAnalysis,
  onNavigate,
  onViewRelatedMemory,
}) => {
  const getSeverityBadgeClass = (severity: string) => {
    switch (severity) {
      case 'Critical':
        return 'text-red-400 bg-red-950/40 border-red-800/60';
      case 'High':
        return 'text-amber-400 bg-amber-950/40 border-amber-800/60';
      case 'Medium':
        return 'text-blue-400 bg-blue-950/40 border-blue-800/60';
      case 'Low':
        return 'text-emerald-400 bg-emerald-950/40 border-emerald-800/60';
      default:
        return 'text-slate-300 bg-slate-800 border-slate-700';
    }
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'Investigating':
        return 'text-amber-300 bg-amber-950/30 border-amber-800/40';
      case 'Resolved':
        return 'text-emerald-300 bg-emerald-950/30 border-emerald-800/40';
      default:
        return 'text-slate-300 bg-slate-800 border-slate-700';
    }
  };

  const defaultTimeline = [
    { time: '19:40:00', event: 'Alert triggered by Prometheus for latency elevation', actor: 'Automated Monitor' },
    { time: '19:41:30', event: 'Incident assigned to SRE team on-call', actor: 'PagerDuty' },
    { time: '19:43:00', event: 'MemoryOps Hindsight query initiated for similar patterns', actor: 'MemoryOps Agent' },
    { time: '19:48:00', event: 'Resolution applied following historical operational guidance', actor: 'Engineering Team' },
  ];

  const timeline = incident.timeline || defaultTimeline;

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Top Navigation & Action */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <button
          onClick={onBack}
          className="text-xs text-slate-400 hover:text-white flex items-center gap-1.5 transition-colors self-start cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Incidents</span>
        </button>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onRunAnalysis(incident)}
            className="px-4 py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-500 rounded-lg shadow-md shadow-purple-950/40 flex items-center gap-2 transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Run AI Analysis</span>
          </button>
        </div>
      </div>

      {/* Main Incident Card */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 shadow-xs space-y-6">
        {/* Title & Metadata Badges */}
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 pb-6 border-b border-slate-800">
          <div>
            <div className="flex flex-wrap items-center gap-2.5 mb-2">
              <span className="font-mono text-sm font-bold text-purple-300 bg-purple-950/40 px-2.5 py-0.5 rounded border border-purple-800/40">
                {incident.id}
              </span>
              <span className={`px-2.5 py-0.5 rounded text-xs font-semibold border ${getSeverityBadgeClass(incident.severity)}`}>
                {incident.severity}
              </span>
              <span className={`px-2.5 py-0.5 rounded text-xs font-medium border ${getStatusBadgeClass(incident.status)}`}>
                {incident.status}
              </span>
              <span className="px-2.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 text-xs">
                {incident.environment}
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              {incident.title}
            </h1>
            <div className="text-xs text-slate-400 mt-1 flex items-center gap-2">
              <span>Service: <strong className="text-slate-200">{incident.service}</strong></span>
              <span>·</span>
              <span>Type: <strong className="text-purple-300">{incident.incidentType || 'Database Connection Timeout'}</strong></span>
              <span>·</span>
              <span>Logged: <strong className="text-slate-200 font-mono">{incident.date}, 2026</strong></span>
            </div>
          </div>

          <div className="shrink-0">
            {incident.status === 'Resolved' || incident.memoryStatus === 'Retained' ? (
              <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-600/50 flex items-center gap-2 text-xs font-semibold text-purple-200">
                <BrainCircuit className="w-4 h-4 text-purple-400" />
                <span>🧠 Retained in Memory</span>
              </div>
            ) : (
              <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-800/40 flex items-center gap-2 text-xs font-medium text-amber-300">
                <Clock className="w-4 h-4 text-amber-400" />
                <span>Pending Resolution & Retention</span>
              </div>
            )}
          </div>
        </div>

        {/* 1. Description */}
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
            Description
          </h3>
          <p className="text-sm text-slate-200 leading-relaxed bg-slate-900/60 p-4 rounded-lg border border-slate-800">
            {incident.description}
          </p>
        </div>

        {/* 2. Logs */}
        {incident.logs && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-purple-400" />
                <span>Logs & Error Traces</span>
              </h3>
              <span className="text-[11px] text-slate-500 font-mono">stdout/stderr telemetry</span>
            </div>
            <pre className="p-4 bg-slate-950 rounded-lg border border-slate-800 text-xs font-mono text-purple-300/90 whitespace-pre-wrap overflow-x-auto leading-relaxed">
              {incident.logs}
            </pre>
          </div>
        )}

        {/* 3. Root Cause & Resolution */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1.5">
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-400">
              Root Cause
            </span>
            <p className="text-sm text-slate-200 font-medium leading-relaxed">
              {incident.rootCause || 'Database connection pool exhaustion under sudden traffic burst.'}
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1.5">
            <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400">
              Resolution
            </span>
            <p className="text-sm text-slate-200 leading-relaxed">
              {incident.resolution || 'Increased database connection pool from 20 to 50 and restarted the affected service.'}
            </p>
          </div>
        </div>

        {/* 4. Timeline */}
        <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Clock className="w-3.5 h-3.5 text-purple-400" />
              <span>Incident Timeline</span>
            </h3>
            <span className="text-[11px] text-slate-400">Chronological telemetry audit</span>
          </div>

          <div className="space-y-3 pt-2">
            {timeline.map((item, index) => (
              <div key={index} className="flex items-start gap-3 text-xs">
                <span className="font-mono text-purple-400 tabular-nums shrink-0 mt-0.5">{item.time}</span>
                <span className="text-slate-600">·</span>
                <div className="flex-1">
                  <span className="text-slate-200">{item.event}</span>
                  <span className="text-slate-400 text-[11px] ml-2 font-mono">({item.actor})</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 5. Related Memories */}
        <div className="p-5 rounded-xl bg-gradient-to-r from-purple-950/30 to-indigo-950/20 border border-purple-800/40 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-300 flex items-center gap-1.5">
              <Database className="w-3.5 h-3.5" />
              <span>Related Hindsight Operational Memories ({incident.memoriesCount})</span>
            </span>
            <button
              onClick={() => onNavigate('memory-explorer')}
              className="text-xs text-purple-400 hover:text-purple-300 font-medium flex items-center gap-1 cursor-pointer"
            >
              <span>Explore All Memories</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            Correlated with historical incidents {incident.relatedIncidents?.join(', ') || 'INC-017, INC-011, INC-004'}. MemoryOps automatically leveraged these historical operational memories to generate the recommended connection pool scaling fix.
          </p>

          <div className="pt-2 flex flex-wrap gap-2">
            {(incident.relatedIncidents || ['INC-017', 'INC-011', 'INC-004']).map((relId) => (
              <button
                key={relId}
                onClick={() => onNavigate('memory-explorer')}
                className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-purple-700/50 text-xs font-mono text-purple-300 flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <BrainCircuit className="w-3 h-3 text-purple-400" />
                <span>Memory from {relId}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
