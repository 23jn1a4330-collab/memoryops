import React, { useState } from 'react';
import { 
  Database, 
  Search, 
  BrainCircuit, 
  Calendar, 
  Check, 
  ArrowDown, 
  Sparkles, 
  ExternalLink,
  RotateCcw,
  Tag,
  ShieldAlert,
  Server
} from 'lucide-react';
import { MemoryItem, OperationalReflection, ServiceName, SeverityLevel, HindsightStatus } from '../types';
import { PageId } from '../components/Sidebar';

interface MemoryExplorerPageProps {
  memories: MemoryItem[];
  reflections?: OperationalReflection[];
  onSelectMemory?: (memory: MemoryItem) => void;
  onViewIncident: (incidentId: string) => void;
  onNavigate: (page: PageId) => void;
  hindsightStatus?: HindsightStatus;
}

export const MemoryExplorerPage: React.FC<MemoryExplorerPageProps> = ({
  memories,
  reflections = [],
  onViewIncident,
  onNavigate,
  hindsightStatus,
}) => {
  const [search, setSearch] = useState('');
  const [selectedService, setSelectedService] = useState<string>('All');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('All');
  const [selectedIncidentType, setSelectedIncidentType] = useState<string>('All');
  const [sourceFilter, setSourceFilter] = useState<'all' | 'real' | 'local'>('all');

  const services = [
    'All',
    'Payment API',
    'Authentication Service',
    'Database Service',
    'Notification Service',
    'Order Service',
  ];

  const severities = ['All', 'Critical', 'High', 'Medium', 'Low'];

  // Extract unique incident types from memories
  const incidentTypes = [
    'All',
    ...Array.from(new Set(memories.map((m) => m.incidentType).filter(Boolean))),
  ];

  const realMemoriesCount = memories.filter((m) => m.isRealHindsight || m.source === 'Hindsight Cloud').length;
  const localMemoriesCount = memories.filter((m) => !m.isRealHindsight && m.source !== 'Hindsight Cloud').length;
  // Real Hindsight API count
  const apiIndexedCount = hindsightStatus?.connected ? (hindsightStatus.count ?? 0) : localMemoriesCount;

  const filteredMemories = memories
    .filter((mem) => {
      const isReal = mem.isRealHindsight || mem.source === 'Hindsight Cloud';
      if (sourceFilter === 'real' && !isReal) return false;
      if (sourceFilter === 'local' && isReal) return false;

      const query = search.toLowerCase().trim();
      const matchesSearch =
        query === '' ||
        mem.id.toLowerCase().includes(query) ||
        mem.incidentId.toLowerCase().includes(query) ||
        mem.title.toLowerCase().includes(query) ||
        mem.service.toLowerCase().includes(query) ||
        mem.incidentType?.toLowerCase().includes(query) ||
        mem.rootCause.toLowerCase().includes(query) ||
        mem.previousResolution.toLowerCase().includes(query) ||
        mem.tags.some((t) => t.toLowerCase().includes(query));

      const matchesService = selectedService === 'All' || mem.service === selectedService;
      const matchesSeverity = selectedSeverity === 'All' || mem.severity === selectedSeverity;
      const matchesIncidentType =
        selectedIncidentType === 'All' || mem.incidentType === selectedIncidentType;

      return matchesSearch && matchesService && matchesSeverity && matchesIncidentType;
    })
    .sort((a, b) => {
      // Prioritize REAL HINDSIGHT MEMORY when connected
      if (hindsightStatus?.connected) {
        const aReal = a.isRealHindsight || a.source === 'Hindsight Cloud';
        const bReal = b.isRealHindsight || b.source === 'Hindsight Cloud';
        if (aReal && !bReal) return -1;
        if (!aReal && bReal) return 1;
      }
      return 0;
    });

  const handleResetFilters = () => {
    setSearch('');
    setSelectedService('All');
    setSelectedSeverity('All');
    setSelectedIncidentType('All');
    setSourceFilter('all');
  };

  const isFiltered =
    search !== '' ||
    selectedService !== 'All' ||
    selectedSeverity !== 'All' ||
    selectedIncidentType !== 'All' ||
    sourceFilter !== 'all';

  const getSeverityBadge = (sev: SeverityLevel) => {
    switch (sev) {
      case 'Critical':
        return 'text-red-400 bg-red-950/40 border-red-800/60';
      case 'High':
        return 'text-amber-400 bg-amber-950/40 border-amber-800/60';
      case 'Medium':
        return 'text-blue-400 bg-blue-950/40 border-blue-800/60';
      case 'Low':
        return 'text-emerald-400 bg-emerald-950/40 border-emerald-800/60';
      default:
        return 'text-slate-300 bg-slate-800 border-slate-700';
    }
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider mb-1">
            <Database className="w-4 h-4 text-purple-400" />
            {hindsightStatus?.connected ? (
              <span className="text-purple-300">Hindsight Cloud Active (Bank: MemoryOps)</span>
            ) : (
              <span className="text-amber-400">Hindsight Cloud Offline (Local Fallback)</span>
            )}
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">Memory Explorer</h1>
          <p className="text-sm text-slate-400 mt-1">
            Explore what MemoryOps has learned from previous incidents. Every resolved outage is retained here.
          </p>
        </div>

        <div className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-300">
          <BrainCircuit className="w-4 h-4 text-purple-400" />
          <span><strong className="text-white font-mono text-sm">{apiIndexedCount}</strong> Memories Indexed</span>
          {hindsightStatus?.connected ? (
            <span className="inline-flex items-center gap-1 ml-1 px-1.5 py-0.5 rounded bg-emerald-950/60 border border-emerald-800 text-emerald-400 text-[10px] font-mono font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Active
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 ml-1 px-1.5 py-0.5 rounded bg-amber-950/60 border border-amber-800 text-amber-400 text-[10px] font-mono">
              Offline
            </span>
          )}
        </div>
      </div>

      {/* Memory Category Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800/80 pb-2 text-xs">
        <button
          onClick={() => setSourceFilter('all')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            sourceFilter === 'all'
              ? 'bg-purple-600/20 text-purple-300 border border-purple-500/40'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          All Memories ({memories.length})
        </button>
        <button
          onClick={() => setSourceFilter('real')}
          className={`px-3 py-1.5 rounded-lg font-medium flex items-center gap-1.5 transition-colors ${
            sourceFilter === 'real'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-purple-300 bg-purple-950/30 border border-purple-800/40 hover:bg-purple-900/40'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-purple-300" />
          <span>Real Hindsight Memories ({realMemoriesCount})</span>
        </button>
        <button
          onClick={() => setSourceFilter('local')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            sourceFilter === 'local'
              ? 'bg-slate-700 text-white'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          Local Demo Memories ({localMemoriesCount})
        </button>
      </div>

      {/* Search & 3 Filters (Service, Severity, Incident Type) */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-xs space-y-3">
        <div className="flex flex-col lg:flex-row gap-3">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search operational memory by keyword, root cause, resolution, tags..."
              className="w-full pl-10 pr-4 py-2 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
            />
          </div>

          {/* 3 Filters */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {/* Filter 1: Service */}
            <select
              value={selectedService}
              onChange={(e) => setSelectedService(e.target.value)}
              className="px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 text-xs focus:outline-hidden focus:border-purple-500"
            >
              {services.map((svc) => (
                <option key={svc} value={svc}>
                  {svc === 'All' ? 'All Services' : svc}
                </option>
              ))}
            </select>

            {/* Filter 2: Severity */}
            <select
              value={selectedSeverity}
              onChange={(e) => setSelectedSeverity(e.target.value)}
              className="px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 text-xs focus:outline-hidden focus:border-purple-500"
            >
              {severities.map((sev) => (
                <option key={sev} value={sev}>
                  {sev === 'All' ? 'All Severities' : sev}
                </option>
              ))}
            </select>

            {/* Filter 3: Incident Type */}
            <select
              value={selectedIncidentType}
              onChange={(e) => setSelectedIncidentType(e.target.value)}
              className="px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 text-xs focus:outline-hidden focus:border-purple-500 max-w-[200px] truncate"
            >
              {incidentTypes.map((type) => (
                <option key={type} value={type}>
                  {type === 'All' ? 'All Incident Types' : type}
                </option>
              ))}
            </select>

            {/* Filter 4: Source (Real Hindsight vs Local Demo) */}
            <div className="inline-flex rounded-lg p-0.5 bg-slate-900 border border-slate-700 text-xs">
              <button
                type="button"
                onClick={() => setSourceFilter('all')}
                className={`px-2.5 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                  sourceFilter === 'all'
                    ? 'bg-slate-800 text-white shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                All ({memories.length})
              </button>
              <button
                type="button"
                onClick={() => setSourceFilter('real')}
                className={`px-2.5 py-1.5 rounded-md font-medium transition-colors flex items-center gap-1 cursor-pointer ${
                  sourceFilter === 'real'
                    ? 'bg-purple-900/60 text-purple-200 border border-purple-700/50 shadow-xs'
                    : 'text-purple-300/80 hover:text-purple-200'
                }`}
              >
                <Sparkles className="w-3 h-3 text-purple-400" />
                Real Hindsight ({realMemoriesCount})
              </button>
              <button
                type="button"
                onClick={() => setSourceFilter('local')}
                className={`px-2.5 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                  sourceFilter === 'local'
                    ? 'bg-slate-800 text-slate-200 shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Local Demo ({localMemoriesCount})
              </button>
            </div>

            {isFiltered && (
              <button
                onClick={handleResetFilters}
                className="px-2.5 py-2 text-xs text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors flex items-center gap-1"
                title="Reset filters"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            )}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between text-[11px] text-slate-400 pt-1 gap-1">
          <span>
            Showing <strong className="text-white font-mono">{filteredMemories.length}</strong> operational {filteredMemories.length === 1 ? 'memory' : 'memories'}
            {hindsightStatus?.connected && (
              <span className="text-purple-300 ml-1">
                ({apiIndexedCount} indexed in Hindsight Cloud bank <code className="font-mono text-purple-200">MemoryOps</code>)
              </span>
            )}
          </span>
          <span className="text-slate-400">
            {hindsightStatus?.connected
              ? 'Hindsight Cloud Vector Bank Active'
              : 'Local Fallback Storage Active'}
          </span>
        </div>
      </div>

      {/* Memory Timeline / Card Layout */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
            <Calendar className="w-4 h-4 text-purple-400" />
            <span>Retained Memory Timeline</span>
          </h2>
          <span className="text-xs text-slate-400">Chronological Hindsight storage</span>
        </div>

        {filteredMemories.length === 0 ? (
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-12 text-center">
            <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center mx-auto text-slate-400 mb-3">
              <Database className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-semibold text-white">No matching memories found</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              No operational memories match your current search and filters. Try clearing search terms or selecting another service.
            </p>
            <button
              onClick={handleResetFilters}
              className="mt-4 px-3.5 py-1.5 rounded-lg bg-slate-800 text-xs text-purple-300 hover:bg-slate-700 transition-colors"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredMemories.map((mem) => (
              <div
                key={mem.id}
                className="bg-[#111827] border border-slate-800 hover:border-slate-700 rounded-xl p-5 shadow-xs transition-colors flex flex-col justify-between gap-4 group"
              >
                {/* Top Row: Incident ID, Service, Severity, Incident Type, Date */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-3 border-b border-slate-800/80">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-xs font-bold text-purple-300 bg-purple-950/40 px-2.5 py-0.5 rounded border border-purple-800/40">
                      {mem.incidentId === 'INC-017' ? 'Incident #017' : mem.incidentId}
                    </span>
                    <span className="text-sm font-bold text-white">
                      {mem.service}
                    </span>
                    <span className="text-slate-500 font-semibold">·</span>
                    <span className={`px-2 py-0.5 rounded text-[11px] font-semibold border ${getSeverityBadge(mem.severity)}`}>
                      {mem.severity}
                    </span>
                    <span className="text-slate-500 font-semibold">·</span>
                    <span className="text-xs font-medium text-purple-200">
                      {mem.incidentType || 'Database Connection Timeout'}
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-mono text-slate-400">
                      {mem.date}
                    </span>
                    {mem.isRealHindsight || mem.source === 'Hindsight Cloud' ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-purple-500/20 border border-purple-500/50 text-purple-300 font-mono text-[10px] font-bold tracking-wide shadow-xs">
                        <Sparkles className="w-3 h-3 text-purple-400" />
                        REAL HINDSIGHT MEMORY
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-slate-800/90 border border-slate-700 text-slate-400 font-mono text-[10px] tracking-wide">
                        LOCAL DEMO MEMORY
                      </span>
                    )}
                  </div>
                </div>

                {/* Main Content Grid: Root Cause, Resolution, Outcome */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                  {/* Root Cause */}
                  <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-amber-400 block mb-1">
                      Root Cause:
                    </span>
                    <p className="text-sm font-medium text-slate-200 leading-relaxed">{mem.rootCause}</p>
                  </div>

                  {/* Resolution */}
                  <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-purple-300 block mb-1">
                      Resolution:
                    </span>
                    <p className="text-xs text-slate-300 leading-relaxed">{mem.previousResolution}</p>
                  </div>

                  {/* Outcome */}
                  <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 flex flex-col justify-between">
                    <div>
                      <span className="text-[10px] font-semibold uppercase tracking-wider text-emerald-400 block mb-1">
                        Outcome:
                      </span>
                      <p className="text-xs font-medium text-emerald-400 flex items-center gap-1.5">
                        <Check className="w-4 h-4" />
                        {mem.outcome}
                      </p>
                    </div>

                    <div className="pt-2 mt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                      <span className="text-slate-400 font-mono">Relevance: {mem.relevance}%</span>
                      <button
                        onClick={() => onViewIncident(mem.incidentId)}
                        className="text-purple-400 hover:text-purple-300 font-medium flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        <span>Inspect Incident</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Bottom Tags */}
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  {mem.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800/80 text-slate-400 border border-slate-700/60 flex items-center gap-1"
                    >
                      <Tag className="w-2.5 h-2.5 text-slate-500" />
                      <span>#{tag}</span>
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* SECTION: How MemoryOps Learns (Visual Closed-Loop Lifecycle) */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 sm:p-8 shadow-xs space-y-6">
        <div className="text-center max-w-xl mx-auto space-y-1">
          <h2 className="text-lg font-bold text-white tracking-tight">How MemoryOps Learns</h2>
          <p className="text-xs text-slate-400">
            The closed-loop lifecycle that turns resolved operational outages into continuous engineering knowledge
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 relative">
          {/* Card 1: RETAIN */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-center relative flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 mx-auto rounded-xl bg-purple-600/20 text-purple-400 border border-purple-500/30 flex items-center justify-center mb-3">
                <Database className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">RETAIN</h3>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                Remember important incident information and verified fixes.
              </p>
            </div>
            <div className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold mt-4">
              Phase 01
            </div>
          </div>

          {/* Card 2: RECALL */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-center relative flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 mx-auto rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center mb-3">
                <Search className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">RECALL</h3>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                Find relevant past experiences using semantic vector indexing.
              </p>
            </div>
            <div className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold mt-4">
              Phase 02
            </div>
          </div>

          {/* Card 3: REFLECT */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-center relative flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 mx-auto rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center mb-3">
                <BrainCircuit className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">REFLECT</h3>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                Reason over historical patterns and recurring failure modes.
              </p>
            </div>
            <div className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold mt-4">
              Phase 03
            </div>
          </div>

          {/* Card 4: RECOMMEND */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-center relative flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 mx-auto rounded-xl bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mb-3">
                <Sparkles className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">RECOMMEND</h3>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                Generate high-confidence, context-aware operational guidance.
              </p>
            </div>
            <div className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold mt-4">
              Phase 04
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
