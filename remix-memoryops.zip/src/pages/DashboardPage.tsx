import React from 'react';
import { 
  Plus, 
  Play, 
  BrainCircuit, 
  AlertOctagon, 
  CheckCircle2, 
  Database, 
  TrendingUp, 
  Clock, 
  ArrowRight,
  ShieldAlert,
  Server,
  Sparkles,
  ExternalLink,
  AlertTriangle
} from 'lucide-react';
import { Incident, MemoryInsight, HindsightStatus } from '../types';
import { IncidentActivityChart } from '../components/charts/IncidentActivityChart';
import { SeverityDonutChart } from '../components/charts/SeverityDonutChart';
import { PageId } from '../components/Sidebar';

interface DashboardPageProps {
  incidents: Incident[];
  insight: MemoryInsight;
  memoriesCount?: number;
  onNavigate: (page: PageId) => void;
  onSelectIncident: (inc: Incident) => void;
  onStartDemoTour: () => void;
  hindsightStatus?: HindsightStatus;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  incidents,
  insight,
  memoriesCount,
  onNavigate,
  onSelectIncident,
  onStartDemoTour,
  hindsightStatus,
}) => {
  const displayMemoriesCount = hindsightStatus?.connected 
    ? (hindsightStatus.count ?? 0)
    : (typeof memoriesCount === 'number' ? memoriesCount : incidents.length);

  // Recent 5 incidents
  const recentIncidents = incidents.slice(0, 5);

  const totalIncidentsCount = incidents.length;
  const criticalIncidentsCount = incidents.filter((i) => i.severity === 'Critical').length;
  const resolvedIncidentsCount = incidents.filter((i) => i.status === 'Resolved').length;
  const resolutionRate = totalIncidentsCount > 0 ? Math.round((resolvedIncidentsCount / totalIncidentsCount) * 100) : 83;

  const getSeverityBadgeClass = (severity: string) => {
    switch (severity) {
      case 'Critical':
        return 'text-red-400 bg-red-950/40 border-red-800/60';
      case 'High':
        return 'text-amber-400 bg-amber-950/40 border-amber-800/60';
      case 'Medium':
        return 'text-blue-400 bg-blue-950/40 border-blue-800/60';
      case 'Low':
        return 'text-emerald-400 bg-emerald-950/40 border-emerald-800/60';
      default:
        return 'text-slate-300 bg-slate-800 border-slate-700';
    }
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'Investigating':
        return 'text-amber-300 bg-amber-950/30 border-amber-800/40';
      case 'Resolved':
        return 'text-emerald-300 bg-emerald-950/30 border-emerald-800/40';
      default:
        return 'text-slate-300 bg-slate-800 border-slate-700';
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Welcome & Actions */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            Good morning, Engineer
          </h1>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl">
            Monitor incidents, investigate recurring issues, and resolve problems using historical operational memory.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onNavigate('new-incident')}
            className="px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg flex items-center gap-2 transition-colors cursor-pointer shadow-xs"
          >
            <Plus className="w-4 h-4 text-purple-400" />
            <span>+ New Incident</span>
          </button>

          <button
            onClick={onStartDemoTour}
            className="px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 rounded-lg shadow-lg shadow-purple-950/50 flex items-center gap-2 transition-all transform hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>Run Memory Demo</span>
          </button>
        </div>
      </div>

      {/* Prominent banner if Hindsight is not connected */}
      {!hindsightStatus?.connected && (
        <div className="p-3.5 bg-amber-950/30 border border-amber-800/60 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-amber-200">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-amber-900/50 text-amber-400 shrink-0">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div>
              <strong className="text-amber-300 font-semibold">Hindsight Cloud Offline:</strong>{' '}
              <span>Running in local vector fallback mode. Connect HINDSIGHT_API_KEY to enable Hindsight Cloud memory retrieval.</span>
            </div>
          </div>
          <button
            onClick={() => onNavigate('settings')}
            className="text-[11px] font-medium text-amber-300 hover:text-white underline self-start sm:self-auto cursor-pointer"
          >
            Configure Hindsight →
          </button>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Incidents */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Incidents</span>
            <div className="p-2 rounded-lg bg-slate-800/80 text-purple-400">
              <Server className="w-4 h-4" />
            </div>
          </div>
          <div className="my-3">
            <div className="text-3xl font-bold text-white font-mono tabular-nums">{totalIncidentsCount}</div>
            <div className="flex items-center gap-1.5 text-xs text-emerald-400 mt-1">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>+12% this month</span>
            </div>
          </div>
          <div className="text-[11px] text-slate-400 border-t border-slate-800/80 pt-2.5">
            Active tracking across 5 services
          </div>
        </div>

        {/* Card 2: Critical Incidents */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Critical Incidents</span>
            <div className="p-2 rounded-lg bg-red-950/40 text-red-400 border border-red-900/40">
              <AlertOctagon className="w-4 h-4" />
            </div>
          </div>
          <div className="my-3">
            <div className="text-3xl font-bold text-white font-mono tabular-nums">{criticalIncidentsCount}</div>
            <div className="flex items-center gap-1.5 text-xs text-amber-400 mt-1">
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>Requires attention</span>
            </div>
          </div>
          <div className="text-[11px] text-slate-400 border-t border-slate-800/80 pt-2.5">
            1 currently under active analysis
          </div>
        </div>

        {/* Card 3: Resolved Incidents */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Resolved Incidents</span>
            <div className="p-2 rounded-lg bg-emerald-950/40 text-emerald-400 border border-emerald-900/40">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="my-3">
            <div className="text-3xl font-bold text-white font-mono tabular-nums">{resolvedIncidentsCount}</div>
            <div className="flex items-center gap-1.5 text-xs text-emerald-400 mt-1">
              <span>{resolutionRate}% resolution rate</span>
            </div>
          </div>
          <div className="text-[11px] text-slate-400 border-t border-slate-800/80 pt-2.5">
            MTTR reduced by 41% with memory
          </div>
        </div>

        {/* Card 4: Memories Stored */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-purple-600/10 rounded-full blur-2xl pointer-events-none" />
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-300">Memories Stored</span>
            <div className="p-2 rounded-lg bg-purple-950/40 text-purple-400 border border-purple-800/40">
              <Database className="w-4 h-4" />
            </div>
          </div>
          <div className="my-3">
            <div className="text-3xl font-bold text-white font-mono tabular-nums">{displayMemoriesCount}</div>
            <div className="flex items-center gap-1.5 text-xs text-purple-300 mt-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{hindsightStatus?.connected ? 'Real Hindsight Bank' : 'Local Fallback'}</span>
            </div>
          </div>
          <div className="text-[11px] text-slate-400 border-t border-slate-800/80 pt-2.5">
            {hindsightStatus?.connected ? (
              <span className="text-purple-300 font-medium">Hindsight Cloud Active (Bank: MemoryOps)</span>
            ) : (
              <span className="text-amber-400/90 font-medium">Hindsight Cloud Offline (Fallback)</span>
            )}
          </div>
        </div>
      </div>

      {/* Visual Charts Grid: Activity & Severity Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <IncidentActivityChart />
        </div>
        <div>
          <SeverityDonutChart />
        </div>
      </div>

      {/* Recent Incidents Table */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden shadow-xs">
        <div className="p-5 border-b border-slate-800/80 flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold text-white tracking-tight">Recent Incidents</h2>
            <p className="text-xs text-slate-400 mt-0.5">Click any incident to inspect root cause and memory correlations</p>
          </div>
          <button
            onClick={() => onNavigate('incidents')}
            className="text-xs text-purple-400 hover:text-purple-300 font-medium flex items-center gap-1 transition-colors"
          >
            <span>View all 24</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/70 border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">ID</th>
                <th className="py-3 px-4">Service</th>
                <th className="py-3 px-4">Incident</th>
                <th className="py-3 px-4">Severity</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Memory</th>
                <th className="py-3 px-4 text-right">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {recentIncidents.map((inc) => (
                <tr
                  key={inc.id}
                  onClick={() => onSelectIncident(inc)}
                  className="hover:bg-slate-800/50 transition-colors cursor-pointer group"
                >
                  <td className="py-3.5 px-4 font-mono font-semibold text-purple-300 group-hover:text-purple-200">
                    {inc.id}
                  </td>
                  <td className="py-3.5 px-4 text-slate-300 font-medium whitespace-nowrap">
                    {inc.service}
                  </td>
                  <td className="py-3.5 px-4 text-slate-200 font-medium max-w-xs truncate">
                    {inc.title}
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold border ${getSeverityBadgeClass(
                        inc.severity
                      )}`}
                    >
                      {inc.severity}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium border ${getStatusBadgeClass(
                        inc.status
                      )}`}
                    >
                      {inc.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-purple-950/30 border border-purple-800/30 text-purple-300 font-mono text-[11px]">
                      <BrainCircuit className="w-3 h-3 text-purple-400" />
                      {inc.memoriesCount} memories
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right text-slate-400 font-mono tabular-nums whitespace-nowrap">
                    {inc.date}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Memory-powered Insight Card */}
      <div className="bg-gradient-to-r from-purple-950/30 via-slate-900 to-indigo-950/20 border border-purple-800/40 rounded-xl p-6 shadow-lg shadow-purple-950/30">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 flex-1">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-purple-600/20 text-purple-300 border border-purple-500/30">
                <BrainCircuit className="w-4 h-4" />
              </span>
              <h3 className="text-base font-semibold text-white tracking-tight">
                🧠 Memory-powered Insight
              </h3>
            </div>
            <p className="text-sm text-slate-200 leading-relaxed font-normal">
              "{insight.summary}"
            </p>
            <div className="flex flex-wrap items-center gap-3 pt-2 text-xs text-slate-300">
              <div className="px-3 py-1 rounded-md bg-slate-800/80 border border-slate-700/80 flex items-center gap-1.5 font-mono">
                <span className="w-2 h-2 rounded-full bg-purple-400" />
                <strong className="text-white tabular-nums">{insight.relatedIncidentsCount}</strong> Related Incidents
              </div>
              <div className="px-3 py-1 rounded-md bg-slate-800/80 border border-slate-700/80 flex items-center gap-1.5 font-mono">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <strong className="text-white tabular-nums">{insight.successfulResolutionsCount}</strong> Successful Resolutions
              </div>
              <div className="px-3 py-1 rounded-md bg-slate-800/80 border border-slate-700/80 flex items-center gap-1.5 font-mono">
                <span className="w-2 h-2 rounded-full bg-blue-400" />
                <strong className="text-white tabular-nums">{insight.recurringPatternsCount}</strong> Recurring Pattern
              </div>
            </div>
          </div>

          <div className="shrink-0">
            <button
              onClick={() => onNavigate('memory-explorer')}
              className="w-full sm:w-auto px-5 py-2.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs sm:text-sm font-semibold shadow-md shadow-purple-950/40 flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <span>Explore Memory</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* System Status Footer Bar */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl px-5 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-4 sm:gap-6 text-slate-300">
          <div className="flex items-center gap-2">
            <span className="text-slate-400 font-medium">AI Engine</span>
            <span className="flex items-center gap-1 text-emerald-400 font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Online
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-slate-400 font-medium">Memory Engine</span>
            {hindsightStatus?.connected ? (
              <span className="flex items-center gap-1 text-emerald-400 font-medium">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Hindsight Cloud Online
              </span>
            ) : (
              <span className="flex items-center gap-1 text-amber-400 font-medium">
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                Hindsight Not Connected (Fallback)
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <span className="text-slate-400 font-medium">Application API</span>
            <span className="flex items-center gap-1 text-emerald-400 font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              Operational
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 text-slate-400 font-mono text-[11px]">
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          <span>Last Analysis: <strong className="text-slate-300 font-normal">2 minutes ago</strong></span>
        </div>
      </div>
    </div>
  );
};
