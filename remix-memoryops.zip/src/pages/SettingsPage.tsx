import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, 
  BrainCircuit, 
  Database, 
  Server, 
  Check, 
  ShieldCheck, 
  Sliders, 
  RotateCcw,
  Sparkles,
  Info,
  AlertTriangle,
  ExternalLink
} from 'lucide-react';
import { HindsightStatus } from '../types';

interface SettingsPageProps {
  onResetData: () => void;
  onShowToast: (title: string, msg?: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
  hindsightStatus?: HindsightStatus;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ 
  onResetData, 
  onShowToast,
  hindsightStatus,
}) => {
  const [similarityThreshold, setSimilarityThreshold] = useState(70);
  const [autoRetain, setAutoRetain] = useState(true);
  const [enableDeduplication, setEnableDeduplication] = useState(true);

  const handleSavePreferences = () => {
    onShowToast('Settings Updated', 'Hindsight configuration and thresholds saved.', 'success');
  };

  const handleReset = () => {
    if (window.confirm('Reset all demo incidents and memories to initial seed data?')) {
      onResetData();
      onShowToast('Demo Data Reset', 'Demo data reset and memories reloaded.', 'info');
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">Settings</h1>
        <p className="text-sm text-slate-400 mt-1">
          Configure operational memory engine, AI reasoning thresholds, and demo parameters.
        </p>
      </div>

      <div className="space-y-6">
        {/* SECTION 1: AI Engine */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-purple-600/20 text-purple-400 border border-purple-500/30">
                <BrainCircuit className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-semibold text-white">AI Engine</h2>
                <p className="text-xs text-slate-400">Operational context synthesis and reasoning</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/40 border border-emerald-800/40 text-xs font-medium text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Online</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400 font-medium">Status</span>
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <Check className="w-3.5 h-3.5" /> Online
              </span>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400 font-medium">Mode</span>
              <span className="text-purple-300 font-mono font-medium">Demo</span>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400 font-medium">Model Backend</span>
              <span className="text-slate-300 font-mono">Synthesizer v2.4 (Simulated)</span>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400 font-medium">Prompt Archetype</span>
              <span className="text-slate-300">Context-Aware Operational Recall</span>
            </div>
          </div>
        </div>

        {/* SECTION 2: Memory Engine */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-semibold text-white">Memory Engine</h2>
                <p className="text-xs text-slate-400">Historical incident vector storage and recall (Hindsight Cloud)</p>
              </div>
            </div>
            {hindsightStatus?.connected ? (
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/40 border border-emerald-800/40 text-xs font-medium text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Hindsight Cloud Connected</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-950/40 border border-amber-800/40 text-xs font-medium text-amber-400">
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                <span>Hindsight Not Connected (Fallback)</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400 font-medium">Primary Provider</span>
              <span className="text-white font-semibold flex items-center gap-1.5 font-mono">
                <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                Hindsight Cloud
              </span>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400 font-medium">Memory Bank ID</span>
              <span className="text-purple-300 font-mono font-semibold">MemoryOps</span>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400 font-medium">Connection Status</span>
              {hindsightStatus?.connected ? (
                <span className="text-emerald-400 font-semibold flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" /> Online (200 OK)
                </span>
              ) : (
                <span className="text-amber-400 font-semibold flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5" /> Not Connected
                </span>
              )}
            </div>

            <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400 font-medium">Active Runtime Driver</span>
              <span className={hindsightStatus?.connected ? 'text-emerald-300 font-mono font-medium' : 'text-amber-300 font-mono font-medium'}>
                {hindsightStatus?.connected ? 'Hindsight Cloud API' : 'Local Vector Fallback Driver'}
              </span>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400 font-medium">Cloud Base URL</span>
              <span className="text-slate-300 font-mono text-[11px]">https://api.hindsight.vectorize.io</span>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400 font-medium">Memories Indexed in Cloud</span>
              <span className="text-purple-300 font-mono font-semibold">
                {hindsightStatus?.connected ? hindsightStatus.count : 'Offline'}
              </span>
            </div>
          </div>

          {!hindsightStatus?.connected && (
            <div className="p-3.5 rounded-lg bg-amber-950/20 border border-amber-800/40 text-xs text-amber-200 space-y-1.5">
              <div className="font-semibold flex items-center gap-2 text-amber-300">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Notice: Hindsight Cloud is not currently connected</span>
              </div>
              <p className="text-amber-200/90 leading-relaxed text-[11px]">
                The application is operating with the local vector fallback driver. To enable real Hindsight Cloud storage and recall, provide <code className="bg-amber-950/60 px-1 py-0.5 rounded font-mono text-amber-300">HINDSIGHT_API_KEY</code> in your environment variables.
              </p>
            </div>
          )}

          {/* Interactive Memory Threshold Controls */}
          <div className="pt-3 border-t border-slate-800 space-y-4">
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="font-semibold text-slate-300">Memory Recall Similarity Threshold</span>
                <span className="font-mono text-purple-400 font-bold">{similarityThreshold}%</span>
              </div>
              <input
                type="range"
                min="50"
                max="95"
                value={similarityThreshold}
                onChange={(e) => setSimilarityThreshold(Number(e.target.value))}
                className="w-full accent-purple-500 bg-slate-800 cursor-pointer"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Memories with cosine semantic similarity above this threshold are pulled into the AI reasoning prompt.
              </p>
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              <div>
                <span className="font-medium text-slate-300 block">Auto-Retain Resolved Incidents</span>
                <span className="text-[11px] text-slate-400">Automatically push root causes and fixes to Hindsight memory</span>
              </div>
              <button
                type="button"
                onClick={() => setAutoRetain(!autoRetain)}
                className={`w-11 h-6 rounded-full transition-colors relative ${
                  autoRetain ? 'bg-purple-600' : 'bg-slate-700'
                }`}
              >
                <span
                  className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                    autoRetain ? 'left-6' : 'left-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* SECTION 3: Application */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-slate-800 text-slate-300 border border-slate-700">
                <Server className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-semibold text-white">Application</h2>
                <p className="text-xs text-slate-400">Environment and runtime metadata</p>
              </div>
            </div>
            <span className="text-xs font-mono text-slate-400 bg-slate-800 px-2.5 py-0.5 rounded border border-slate-700">
              v1.0 Demo
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800">
              <span className="text-slate-400 block mb-1">Environment:</span>
              <span className="text-emerald-400 font-semibold text-sm">Demo</span>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800">
              <span className="text-slate-400 block mb-1">Version:</span>
              <span className="text-white font-mono font-semibold text-sm">1.0</span>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800">
              <span className="text-slate-400 block mb-1">Theme:</span>
              <span className="text-purple-300 font-semibold text-sm">Dark (Default)</span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex items-start gap-3 text-xs text-slate-300">
            <Info className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              This application runs 100% locally in browser memory without requiring external API keys. Real Hindsight and production LLM integrations can be plugged into <code className="text-purple-300 font-mono">src/services/aiService.ts</code> and <code className="text-purple-300 font-mono">src/services/memoryService.ts</code>.
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
            <button
              type="button"
              onClick={handleReset}
              className="w-full sm:w-auto px-4 py-2 text-xs font-medium text-red-300 bg-red-950/30 hover:bg-red-900/40 border border-red-800/40 rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Seed Demo Data</span>
            </button>

            <button
              type="button"
              onClick={handleSavePreferences}
              className="w-full sm:w-auto px-5 py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-500 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              Save Preferences
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
