import React, { useState } from 'react';
import { 
  Sparkles, 
  RotateCcw, 
  BrainCircuit, 
  Check, 
  Loader2, 
  Terminal, 
  ShieldAlert,
  Server
} from 'lucide-react';
import { ServiceName, SeverityLevel, Environment, Incident } from '../types';
import { AnalysisStepStatus } from '../services/aiService';

interface NewIncidentPageProps {
  onAnalyze: (incidentData: {
    service: ServiceName;
    incidentType: string;
    severity: SeverityLevel;
    title: string;
    description: string;
    logs: string;
    environment: Environment;
  }) => void;
  isAnalyzing: boolean;
  analysisSteps: AnalysisStepStatus[];
}

export const NewIncidentPage: React.FC<NewIncidentPageProps> = ({
  onAnalyze,
  isAnalyzing,
  analysisSteps,
}) => {
  const [service, setService] = useState<ServiceName>('Payment API');
  const [severity, setSeverity] = useState<SeverityLevel>('Critical');
  const [incidentType, setIncidentType] = useState('Database Connection Timeout');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [logs, setLogs] = useState('');
  const [environment, setEnvironment] = useState<Environment>('Production');

  const services: ServiceName[] = [
    'Payment API',
    'Authentication Service',
    'Database Service',
    'Notification Service',
    'Order Service',
  ];

  const commonIncidentTypes = [
    'Database Connection Timeout',
    'JWT Expiration Cascade',
    'Connection Limit Threshold',
    'Queue Backlog',
    'Transaction Deadlock',
    'Webhook Latency Spike',
  ];

  const severities: SeverityLevel[] = ['Low', 'Medium', 'High', 'Critical'];
  const environments: Environment[] = ['Production', 'Staging', 'Development'];

  // Load Demo Incident with exact requested values
  const handleLoadDemo = () => {
    setService('Payment API');
    setSeverity('Critical');
    setIncidentType('Database Connection Timeout');
    setTitle('Database Connection Timeout on /v2/charge');
    setDescription('Payment requests are failing intermittently during high traffic.');
    setLogs(
      'ERROR: connection pool exhausted\nERROR: timeout waiting for database connection\nERROR: payment request failed'
    );
    setEnvironment('Production');
  };

  const handleClear = () => {
    setTitle('');
    setDescription('');
    setLogs('');
    setIncidentType('Database Connection Timeout');
    setService('Payment API');
    setSeverity('Critical');
    setEnvironment('Production');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) {
      return;
    }

    onAnalyze({
      service,
      incidentType,
      severity,
      title: title.trim() || incidentType,
      description,
      logs: logs || 'ERROR: connection pool exhausted\nERROR: timeout waiting for database connection',
      environment,
    });
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto relative">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">Create New Incident</h1>
          <p className="text-sm text-slate-400 mt-1">
            Describe the incident and let MemoryOps investigate it using historical operational memory.
          </p>
        </div>

        <button
          type="button"
          onClick={handleLoadDemo}
          className="px-4 py-2 text-xs sm:text-sm font-semibold text-purple-300 bg-purple-950/40 hover:bg-purple-900/50 border border-purple-700/60 rounded-lg flex items-center gap-2 transition-all shadow-xs self-start sm:self-auto cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-purple-400" />
          <span>Load Demo Incident</span>
        </button>
      </div>

      {/* Main Form Card */}
      <form onSubmit={handleSubmit} className="bg-[#111827] border border-slate-800 rounded-xl p-6 shadow-xs space-y-6">
        {/* Row 1: Service & Environment */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Service
            </label>
            <select
              value={service}
              onChange={(e) => setService(e.target.value as ServiceName)}
              className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-sm text-white focus:outline-hidden focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
            >
              {services.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Environment
            </label>
            <div className="grid grid-cols-3 gap-2">
              {environments.map((env) => (
                <button
                  key={env}
                  type="button"
                  onClick={() => setEnvironment(env)}
                  className={`py-2 px-3 text-xs font-medium rounded-lg border text-center transition-colors ${
                    environment === env
                      ? 'bg-purple-600/20 text-purple-300 border-purple-500 shadow-xs'
                      : 'bg-slate-900 text-slate-400 border-slate-700 hover:text-white'
                  }`}
                >
                  {env}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Row 2: Severity Selector */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
            Severity
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {severities.map((sev) => {
              const isSelected = severity === sev;
              const styles = {
                Critical: isSelected ? 'bg-red-950/60 border-red-500 text-red-200' : 'text-slate-400 border-slate-800 hover:border-slate-700',
                High: isSelected ? 'bg-amber-950/60 border-amber-500 text-amber-200' : 'text-slate-400 border-slate-800 hover:border-slate-700',
                Medium: isSelected ? 'bg-blue-950/60 border-blue-500 text-blue-200' : 'text-slate-400 border-slate-800 hover:border-slate-700',
                Low: isSelected ? 'bg-emerald-950/60 border-emerald-500 text-emerald-200' : 'text-slate-400 border-slate-800 hover:border-slate-700',
              };

              return (
                <button
                  key={sev}
                  type="button"
                  onClick={() => setSeverity(sev)}
                  className={`py-2 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all bg-slate-900 ${styles[sev]}`}
                >
                  <span className={`w-2 h-2 rounded-full ${
                    sev === 'Critical' ? 'bg-red-400' : sev === 'High' ? 'bg-amber-400' : sev === 'Medium' ? 'bg-blue-400' : 'bg-emerald-400'
                  }`} />
                  <span>{sev}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Row 3: Incident Type & Optional Title */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Incident Type
            </label>
            <input
              type="text"
              required
              list="incident-types-list"
              value={incidentType}
              onChange={(e) => setIncidentType(e.target.value)}
              placeholder="e.g. Database Connection Timeout"
              className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-hidden focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
            />
            <datalist id="incident-types-list">
              {commonIncidentTypes.map((type) => (
                <option key={type} value={type} />
              ))}
            </datalist>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Incident Title / Summary (Optional)
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Database Connection Timeout on /v2/charge"
              className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-hidden focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
            />
          </div>
        </div>

        {/* Row 4: Description */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
            Description
          </label>
          <textarea
            rows={3}
            required
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Payment requests are failing intermittently during high traffic..."
            className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-hidden focus:border-purple-500 focus:ring-1 focus:ring-purple-500 resize-none font-sans"
          />
        </div>

        {/* Row 5: Logs */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-purple-400" />
              <span>Logs & Error Traces</span>
            </label>
            <span className="text-[11px] text-slate-400">Used by Hindsight for vector matching</span>
          </div>
          <textarea
            rows={4}
            value={logs}
            onChange={(e) => setLogs(e.target.value)}
            placeholder="ERROR: connection pool exhausted&#10;ERROR: timeout waiting for database connection&#10;ERROR: payment request failed"
            className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-lg text-xs font-mono text-purple-200 placeholder-slate-600 focus:outline-hidden focus:border-purple-500 focus:ring-1 focus:ring-purple-500 resize-none leading-relaxed"
          />
        </div>

        {/* Buttons */}
        <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
          <button
            type="button"
            onClick={handleClear}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Clear</span>
          </button>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleLoadDemo}
              className="hidden sm:inline-flex px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
            >
              Load Demo Incident
            </button>

            <button
              type="submit"
              disabled={isAnalyzing || !description.trim()}
              className="px-6 py-2.5 text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-lg shadow-purple-950/50 flex items-center gap-2 transition-all transform hover:scale-[1.01] active:scale-[0.99] cursor-pointer"
            >
              <BrainCircuit className="w-4 h-4" />
              <span>Analyze Incident</span>
            </button>
          </div>
        </div>
      </form>

      {/* Analysis Workflow Modal / Overlay (Exact 4 Steps) */}
      {isAnalyzing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-[#111827] border border-purple-500/50 rounded-2xl shadow-2xl p-6 space-y-6">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 mx-auto rounded-full bg-purple-600/20 text-purple-400 border border-purple-500/40 flex items-center justify-center animate-pulse">
                <BrainCircuit className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white tracking-tight">Analyzing Incident</h3>
              <p className="text-xs text-slate-400">
                Searching historical memory via Hindsight operational engine
              </p>
            </div>

            {/* Stepper list */}
            <div className="space-y-3 bg-slate-900/90 rounded-xl p-4 border border-slate-800">
              {analysisSteps.map((s) => (
                <div key={s.step} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2.5">
                    {s.state === 'completed' && (
                      <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                        <Check className="w-3.5 h-3.5" />
                      </span>
                    )}
                    {s.state === 'active' && (
                      <span className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center shrink-0">
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      </span>
                    )}
                    {s.state === 'pending' && (
                      <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-500 flex items-center justify-center shrink-0 text-[10px] font-mono">
                        ○
                      </span>
                    )}
                    <span
                      className={`font-medium ${
                        s.state === 'completed'
                          ? 'text-slate-200'
                          : s.state === 'active'
                          ? 'text-purple-300 font-semibold'
                          : 'text-slate-500'
                      }`}
                    >
                      Step {s.step}: {s.label}
                    </span>
                  </div>

                  {s.detail && (
                    <span className="text-[11px] font-mono text-purple-400 bg-purple-950/40 px-2 py-0.5 rounded border border-purple-800/40">
                      {s.detail}
                    </span>
                  )}
                </div>
              ))}
            </div>

            <div className="text-center text-xs text-slate-400 font-mono">
              Hindsight Vector Memory Engine Active
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
