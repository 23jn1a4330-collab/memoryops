import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  BrainCircuit, 
  AlertCircle, 
  RotateCcw,
} from 'lucide-react';
import { Incident, SeverityLevel, IncidentStatus } from '../types';
import { PageId } from '../components/Sidebar';

interface IncidentsPageProps {
  incidents: Incident[];
  onNavigate: (page: PageId) => void;
  onSelectIncident: (inc: Incident) => void;
}

export const IncidentsPage: React.FC<IncidentsPageProps> = ({
  incidents,
  onNavigate,
  onSelectIncident,
}) => {
  const [search, setSearch] = useState('');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');

  const severities = ['All', 'Critical', 'High', 'Medium', 'Low'];
  const statuses = ['All', 'Investigating', 'Resolved'];

  const filteredIncidents = incidents.filter((inc) => {
    const query = search.toLowerCase().trim();
    const matchesSearch =
      query === '' ||
      inc.id.toLowerCase().includes(query) ||
      inc.service.toLowerCase().includes(query) ||
      inc.title.toLowerCase().includes(query) ||
      inc.incidentType?.toLowerCase().includes(query) ||
      inc.description.toLowerCase().includes(query) ||
      inc.rootCause?.toLowerCase().includes(query);

    const matchesSeverity = selectedSeverity === 'All' || inc.severity === selectedSeverity;
    const matchesStatus = selectedStatus === 'All' || inc.status === selectedStatus;

    return matchesSearch && matchesSeverity && matchesStatus;
  });

  const getSeverityBadgeClass = (severity: string) => {
    switch (severity) {
      case 'Critical':
        return 'text-red-400 bg-red-950/40 border-red-800/60';
      case 'High':
        return 'text-amber-400 bg-amber-950/40 border-amber-800/60';
      case 'Medium':
        return 'text-blue-400 bg-blue-950/40 border-blue-800/60';
      case 'Low':
        return 'text-emerald-400 bg-emerald-950/40 border-emerald-800/60';
      default:
        return 'text-slate-300 bg-slate-800 border-slate-700';
    }
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'Investigating':
        return 'text-amber-300 bg-amber-950/30 border-amber-800/40';
      case 'Resolved':
        return 'text-emerald-300 bg-emerald-950/30 border-emerald-800/40';
      default:
        return 'text-slate-300 bg-slate-800 border-slate-700';
    }
  };

  const handleResetFilters = () => {
    setSearch('');
    setSelectedSeverity('All');
    setSelectedStatus('All');
  };

  const isFiltered = search !== '' || selectedSeverity !== 'All' || selectedStatus !== 'All';

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">Incidents</h1>
          <p className="text-sm text-slate-400 mt-1">Track and investigate operational incidents.</p>
        </div>

        <button
          onClick={() => onNavigate('new-incident')}
          className="px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-purple-600 hover:bg-purple-500 rounded-lg shadow-md shadow-purple-950/40 flex items-center gap-2 self-start sm:self-auto transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>+ New Incident</span>
        </button>
      </div>

      {/* Search & Filters */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-4 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search incidents by ID, service, incident title, root cause..."
              className="w-full pl-10 pr-4 py-2 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
            />
          </div>

          {/* Severity & Status Filters */}
          <div className="flex items-center gap-2 text-xs">
            <select
              value={selectedSeverity}
              onChange={(e) => setSelectedSeverity(e.target.value)}
              className="px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 focus:outline-hidden focus:border-purple-500 text-xs"
            >
              {severities.map((sev) => (
                <option key={sev} value={sev}>
                  {sev === 'All' ? 'All Severities' : sev}
                </option>
              ))}
            </select>

            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 focus:outline-hidden focus:border-purple-500 text-xs"
            >
              {statuses.map((stat) => (
                <option key={stat} value={stat}>
                  {stat === 'All' ? 'All Statuses' : stat}
                </option>
              ))}
            </select>

            {isFiltered && (
              <button
                onClick={handleResetFilters}
                className="px-2.5 py-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors flex items-center gap-1.5"
                title="Reset filters"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            )}
          </div>
        </div>

        <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
          <span>Showing <strong className="text-white font-mono tabular-nums">{filteredIncidents.length}</strong> of <strong className="text-slate-300 font-mono tabular-nums">{incidents.length}</strong> incidents</span>
          <span className="text-slate-400">Click any row to open incident details</span>
        </div>
      </div>

      {/* Required Table Columns: ID, Service, Severity, Incident, Status, Date */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden shadow-xs">
        {filteredIncidents.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center mx-auto text-slate-400 mb-3">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-semibold text-white">No incidents found</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              No incidents match your current search and filter criteria. Try adjusting your query or resetting filters.
            </p>
            <button
              onClick={handleResetFilters}
              className="mt-4 px-3.5 py-1.5 rounded-lg bg-slate-800 text-xs text-purple-300 hover:bg-slate-700 transition-colors"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/80 border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-3 px-4">ID</th>
                  <th className="py-3 px-4">Service</th>
                  <th className="py-3 px-4">Severity</th>
                  <th className="py-3 px-4">Incident</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredIncidents.map((inc) => (
                  <tr
                    key={inc.id}
                    onClick={() => onSelectIncident(inc)}
                    className="hover:bg-slate-800/50 transition-colors cursor-pointer group"
                  >
                    <td className="py-3.5 px-4 font-mono font-semibold text-purple-300 group-hover:text-purple-200 whitespace-nowrap">
                      {inc.id}
                    </td>
                    <td className="py-3.5 px-4 text-slate-300 font-medium whitespace-nowrap">
                      {inc.service}
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold border ${getSeverityBadgeClass(
                          inc.severity
                        )}`}
                      >
                        {inc.severity}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-200 font-medium max-w-md truncate">
                      <div className="flex items-center gap-2">
                        <span className="truncate">{inc.title}</span>
                        {inc.memoriesCount > 0 && (
                          <span className="hidden sm:inline-flex items-center gap-1 px-1.5 py-0.2 rounded bg-purple-950/40 text-purple-400 font-mono text-[10px] shrink-0 border border-purple-800/30">
                            <BrainCircuit className="w-2.5 h-2.5" />
                            {inc.memoriesCount}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium border ${getStatusBadgeClass(
                          inc.status
                        )}`}
                      >
                        {inc.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right text-slate-400 font-mono tabular-nums whitespace-nowrap">
                      {inc.date}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
