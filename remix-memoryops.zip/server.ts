import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const HINDSIGHT_BASE_URL = (process.env.HINDSIGHT_URL || 'https://api.hindsight.vectorize.io').replace(/\/+$/, '');
const HINDSIGHT_API_KEY = process.env.HINDSIGHT_API_KEY || '';
const MEMORY_BANK_ID = 'MemoryOps';

let sessionRetainedCount = 0;

function getHindsightHeaders() {
  return {
    'Authorization': `Bearer ${HINDSIGHT_API_KEY}`,
    'Content-Type': 'application/json',
  };
}

function mapHindsightError(status: number, defaultMsg: string): string {
  if (status === 401) return 'Invalid or expired Hindsight API key.';
  if (status === 404) return 'Memory bank MemoryOps was not found.';
  if (status === 402) return 'Hindsight credits are insufficient.';
  return defaultMsg || `Hindsight Cloud returned HTTP status ${status}.`;
}

function computeMemoryCount(stats: any): number {
  const baseCount = (typeof stats?.total_nodes === 'number' && stats.total_nodes > 0)
    ? stats.total_nodes
    : ((typeof stats?.total_documents === 'number' && stats.total_documents > 0) ? stats.total_documents : 0);
  return baseCount + sessionRetainedCount;
}

async function startServer() {
  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);

  app.use(express.json());

  // ----------------------------------------------------
  // HINDSIGHT PROXY API ROUTES (API Key kept server-side)
  // ----------------------------------------------------

  // 1. Connection Status & Bank Verification
  app.get('/api/hindsight/status', async (req, res) => {
    if (!HINDSIGHT_API_KEY) {
      return res.status(200).json({
        connected: false,
        provider: 'Hindsight Cloud',
        bankId: MEMORY_BANK_ID,
        count: 0,
        error: 'Hindsight credentials missing: HINDSIGHT_API_KEY not configured.',
      });
    }

    try {
      const statsRes = await fetch(`${HINDSIGHT_BASE_URL}/v1/default/banks/${MEMORY_BANK_ID}/stats`, {
        method: 'GET',
        headers: getHindsightHeaders(),
      });

      if (!statsRes.ok) {
        const errorText = await statsRes.text();
        const friendlyError = mapHindsightError(statsRes.status, errorText);
        return res.status(200).json({
          connected: false,
          status: statsRes.status,
          provider: 'Hindsight Cloud',
          bankId: MEMORY_BANK_ID,
          count: 0,
          error: friendlyError,
        });
      }

      const stats = await statsRes.json();
      const count = computeMemoryCount(stats);

      return res.json({
        connected: true,
        status: 200,
        provider: 'Hindsight Cloud',
        bankId: MEMORY_BANK_ID,
        count,
        stats,
      });
    } catch (err: any) {
      console.error('Error contacting Hindsight Cloud:', err.message);
      return res.status(200).json({
        connected: false,
        provider: 'Hindsight Cloud',
        bankId: MEMORY_BANK_ID,
        count: 0,
        error: 'Unable to reach Hindsight Cloud.',
      });
    }
  });

  // 2. Bank Stats
  app.get('/api/hindsight/stats', async (req, res) => {
    if (!HINDSIGHT_API_KEY) {
      return res.status(401).json({
        connected: false,
        error: 'Hindsight credentials missing.',
      });
    }

    try {
      const statsRes = await fetch(`${HINDSIGHT_BASE_URL}/v1/default/banks/${MEMORY_BANK_ID}/stats`, {
        method: 'GET',
        headers: getHindsightHeaders(),
      });

      if (!statsRes.ok) {
        const errorText = await statsRes.text();
        const friendlyError = mapHindsightError(statsRes.status, errorText);
        return res.status(statsRes.status).json({
          connected: false,
          error: friendlyError,
        });
      }

      const stats = await statsRes.json();
      const count = computeMemoryCount(stats);

      return res.json({
        connected: true,
        count,
        stats,
      });
    } catch (err: any) {
      console.error('Failed to get stats from Hindsight Cloud:', err.message);
      return res.status(503).json({
        connected: false,
        error: 'Unable to reach Hindsight Cloud.',
      });
    }
  });

  // 2b. Bank Memories (Real memories list from Hindsight Cloud)
  app.get('/api/hindsight/memories', async (req, res) => {
    if (!HINDSIGHT_API_KEY) {
      return res.status(401).json({
        connected: false,
        items: [],
        error: 'Hindsight credentials missing.',
      });
    }

    try {
      // 1. First get stats to have real count
      const statsRes = await fetch(`${HINDSIGHT_BASE_URL}/v1/default/banks/${MEMORY_BANK_ID}/stats`, {
        method: 'GET',
        headers: getHindsightHeaders(),
      });
      const stats = statsRes.ok ? await statsRes.json() : null;
      const count = computeMemoryCount(stats);

      // 2. Query memories using broad recall
      const recallRes = await fetch(`${HINDSIGHT_BASE_URL}/v1/default/banks/${MEMORY_BANK_ID}/memories/recall`, {
        method: 'POST',
        headers: getHindsightHeaders(),
        body: JSON.stringify({ query: 'incident connection timeout pool exhaustion resolution Payment API' }),
      });

      const recallData = recallRes.ok ? await recallRes.json() : { results: [] };
      return res.json({
        connected: true,
        count,
        results: recallData.results || [],
        entities: recallData.entities || {},
      });
    } catch (err: any) {
      console.error('Failed to get memories from Hindsight Cloud:', err.message);
      return res.status(503).json({
        connected: false,
        items: [],
        error: 'Unable to reach Hindsight Cloud.',
      });
    }
  });

  // 3. RETAIN: Store incident experience into Hindsight Cloud
  app.post('/api/hindsight/retain', async (req, res) => {
    if (!HINDSIGHT_API_KEY) {
      return res.status(401).json({
        success: false,
        error: 'Hindsight credentials missing: HINDSIGHT_API_KEY not configured.',
      });
    }

    let items = req.body.items;

    // Support payload passing either direct items or structured incident object
    if (!items && req.body.incident) {
      const inc = req.body.incident;
      const rootCause = req.body.rootCause || inc.rootCause || 'Unknown root cause';
      const resolution = req.body.resolution || inc.resolution || 'Resolution applied';
      const outcome = req.body.outcome || inc.outcome || 'Resolved successfully';
      const timestamp = new Date().toISOString();

      const content = [
        `Incident ID: ${inc.id}`,
        `Service: ${inc.service}`,
        `Severity: ${inc.severity}`,
        `Incident Type: ${inc.incidentType || 'Database Connection Timeout'}`,
        `Description: ${inc.description}`,
        `Logs: ${inc.logs || 'None'}`,
        `Root Cause: ${rootCause}`,
        `Resolution: ${resolution}`,
        `Outcome: ${outcome}`,
        `Timestamp: ${timestamp}`,
      ].join('\n');

      items = [{ content }];
    }

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Invalid items array for memory retention.',
      });
    }

    try {
      const retainRes = await fetch(`${HINDSIGHT_BASE_URL}/v1/default/banks/${MEMORY_BANK_ID}/memories`, {
        method: 'POST',
        headers: getHindsightHeaders(),
        body: JSON.stringify({ items }),
      });

      if (!retainRes.ok) {
        const errorText = await retainRes.text();
        const friendlyError = mapHindsightError(retainRes.status, errorText);
        return res.status(retainRes.status).json({
          success: false,
          error: friendlyError,
        });
      }

      const result = await retainRes.json();
      sessionRetainedCount += items.length;

      return res.json({
        success: true,
        source: 'Hindsight Cloud',
        bankId: MEMORY_BANK_ID,
        result,
        sessionRetainedCount,
      });
    } catch (err: any) {
      console.error('Failed to retain memory in Hindsight Cloud:', err.message);
      return res.status(503).json({
        success: false,
        error: 'Unable to reach Hindsight Cloud.',
      });
    }
  });

  // 4. RECALL: Query historical memory from Hindsight Cloud
  app.post('/api/hindsight/recall', async (req, res) => {
    if (!HINDSIGHT_API_KEY) {
      return res.status(401).json({
        success: false,
        error: 'Hindsight credentials missing.',
      });
    }

    const query = req.body.query;
    if (!query) {
      return res.status(400).json({
        success: false,
        error: 'Query parameter is required for Hindsight recall.',
      });
    }

    try {
      const recallRes = await fetch(`${HINDSIGHT_BASE_URL}/v1/default/banks/${MEMORY_BANK_ID}/memories/recall`, {
        method: 'POST',
        headers: getHindsightHeaders(),
        body: JSON.stringify({ query }),
      });

      if (!recallRes.ok) {
        const errorText = await recallRes.text();
        const friendlyError = mapHindsightError(recallRes.status, errorText);
        return res.status(recallRes.status).json({
          success: false,
          error: friendlyError,
        });
      }

      const data = await recallRes.json();
      return res.json({
        success: true,
        source: 'Hindsight Cloud',
        bankId: MEMORY_BANK_ID,
        results: data.results || [],
        entities: data.entities || {},
      });
    } catch (err: any) {
      console.error('Failed to recall from Hindsight Cloud:', err.message);
      return res.status(503).json({
        success: false,
        error: 'Unable to reach Hindsight Cloud.',
      });
    }
  });

  // 5. REFLECT: High-level operational pattern synthesis from Hindsight Cloud
  app.post('/api/hindsight/reflect', async (req, res) => {
    if (!HINDSIGHT_API_KEY) {
      return res.status(401).json({
        success: false,
        error: 'Hindsight credentials missing.',
      });
    }

    const { query, context } = req.body;
    if (!query) {
      return res.status(400).json({
        success: false,
        error: 'Query parameter is required for Hindsight reflect.',
      });
    }

    try {
      const reflectRes = await fetch(`${HINDSIGHT_BASE_URL}/v1/default/banks/${MEMORY_BANK_ID}/reflect`, {
        method: 'POST',
        headers: getHindsightHeaders(),
        body: JSON.stringify({
          query,
          context: context || '',
        }),
      });

      if (!reflectRes.ok) {
        const errorText = await reflectRes.text();
        const friendlyError = mapHindsightError(reflectRes.status, errorText);
        return res.status(reflectRes.status).json({
          success: false,
          error: friendlyError,
        });
      }

      const data = await reflectRes.json();
      return res.json({
        success: true,
        source: 'Hindsight Cloud',
        text: data.text || '',
        usage: data.usage || null,
      });
    } catch (err: any) {
      console.error('Failed to reflect from Hindsight Cloud:', err.message);
      return res.status(503).json({
        success: false,
        error: 'Unable to reach Hindsight Cloud.',
      });
    }
  });

  // ----------------------------------------------------
  // VITE MIDDLEWARE (DEV) & STATIC FILE SERVING (PROD)
  // ----------------------------------------------------
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MemoryOps server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
